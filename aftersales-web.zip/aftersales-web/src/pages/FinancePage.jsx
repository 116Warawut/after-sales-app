import React, { useState, useMemo, useEffect } from "react";
import { Wallet, CheckCircle2, Clock, Check, Plus, FileText, Printer, Receipt, Trash2, ShieldCheck } from "lucide-react";
import { Card, EmptyState, PrimaryButton, Modal, Pagination } from "../components/ui";
import { COLORS, formatDateBySetting, displayStoredDate } from "../shared/constants";
import useDbList from "../hooks/useDbList";
import useWebSettings from "../hooks/useWebSettings";
import { updateRow, logActivity, nextInvoiceNumber, getWebSettings } from "../services/firebaseDb";
import { getSessionAdmin } from "../services/session";

// ---------------------------------------------------------------------------
// 🔍 ฟังก์ชันเปรียบเทียบ ID งานซ่อมกับ repair_id ในคำขออะไหล่ให้ตรงกันทุกรูปแบบ
// ---------------------------------------------------------------------------
function matchesRepairId(partRepairId, job) {
  if (partRepairId == null || !job) return false;
  const pId = String(partRepairId).trim();
  const pClean = pId.replace(/^[kK]/, "");
  const jId = String(job.id ?? "").trim();
  const jIdClean = jId.replace(/^[kK]/, "");
  const jRecId = String(job.record_id ?? "").trim();
  const jRecIdClean = jRecId.replace(/^[kK]/, "");

  return (
    pId === jId ||
    pId === jRecId ||
    (pClean && (pClean === jIdClean || pClean === jRecIdClean))
  );
}

// ---------------------------------------------------------------------------
// 🎯 [แก้ไข] เงื่อนไขการออกบิลใหม่ตามวัตถุประสงค์:
// 1. ยังไม่เคยออกบิล (ไม่มี invoice_no และ total_price ยังไม่ถูกตั้ง)
// 2. งานไม่ได้ถูกยกเลิก
// 3. ช่างกรอกราคาประเมินแล้ว (estimated_price > 0)
// 4. มีการขอเบิกอะไหล่สำหรับงานนี้ และทุกรายการแอดมินอนุมัติแล้วเท่านั้น
// ---------------------------------------------------------------------------
function isInvoiceable(r, partRequests = []) {
  if (!r) return false;

  const status = r.status || "";
  if (status.includes("ยกเลิก")) return false;

  const alreadyInvoiced = Number(r.total_price) > 0 || Boolean(r.invoice_no);
  if (alreadyInvoiced) return false;

  const estimatedPrice = Number(r.estimated_price) || 0;
  if (estimatedPrice <= 0) return false;

  const jobParts = (partRequests || []).filter((pr) => matchesRepairId(pr.repair_id, r));
  if (jobParts.length === 0) return false;

  const allApproved = jobParts.every((pr) => pr.status === "อนุมัติแล้ว");
  return allApproved;
}

function getPaymentState(r) {
  const isWarranty = r.is_warranty_covered === true || r.is_warranty_covered === 1;
  if (isWarranty) return "warranty";
  const isPaid = r.is_paid === 1 || r.is_paid === true;
  if (isPaid) return "paid";
  if (r.customer_payment_slip) return "awaiting";
  return "unpaid";
}

function getMachineWarrantyInfo(machine) {
  if (!machine?.warranty_start_date || !machine?.warranty_months) {
    return { active: false, statusText: null };
  }
  const start = new Date(machine.warranty_start_date);
  if (isNaN(start.getTime())) return { active: false, statusText: null };
  const end = new Date(start);
  end.setMonth(end.getMonth() + Number(machine.warranty_months));
  const msPerDay = 1000 * 60 * 60 * 24;
  const today = new Date();
  const daysLeft = Math.round(
    (new Date(end.getFullYear(), end.getMonth(), end.getDate()) -
      new Date(today.getFullYear(), today.getMonth(), today.getDate())) /
      msPerDay
  );
  if (daysLeft < 0) {
    return { active: false, statusText: `ประกันหมดอายุแล้ว (${-daysLeft} วันก่อน)` };
  }
  const months = Math.floor(daysLeft / 30);
  return {
    active: true,
    statusText: months > 0 ? `ประกัน: เหลือประมาณ ${months} เดือน` : `ประกัน: เหลือ ${daysLeft} วัน`,
  };
}

function CreateInvoiceModal({ repairs, partRequests, spareParts, machines, onClose }) {
  // กรองเฉพาะงานที่ช่างกรอกราคาประเมินและอนุมัติอะไหล่ครบแล้ว
  const invoiceableJobs = useMemo(() => {
    return (repairs || []).filter((r) => isInvoiceable(r, partRequests));
  }, [repairs, partRequests]);

  const [repairId, setRepairId] = useState("");
  const [items, setItems] = useState([]);
  const [isWarrantyCovered, setIsWarrantyCovered] = useState(false);
  const [warrantyStatusText, setWarrantyStatusText] = useState(null);
  const [discount, setDiscount] = useState("");
  const [includeVat, setIncludeVat] = useState(true);
  const [enableWht, setEnableWht] = useState(false);
  const [whtRate, setWhtRate] = useState(3);
  const [saving, setSaving] = useState(false);

  const selectedJob = invoiceableJobs.find((r) => String(r.id) === String(repairId));

  const machineById = useMemo(() => {
    const map = new Map();
    (machines || []).forEach((m) => map.set(String(m.id), m));
    return map;
  }, [machines]);

  function priceForPartId(partId) {
    const part = (spareParts || []).find((p) => String(p.id) === String(partId));
    return Number(part?.price) || 0;
  }

  // คำขอเบิกอะไหล่ที่อนุมัติแล้วของงานนี้
  const availablePartRequests = useMemo(() => {
    if (!selectedJob) return [];
    return (partRequests || []).filter(
      (pr) => matchesRepairId(pr.repair_id, selectedJob) && pr.status === "อนุมัติแล้ว"
    );
  }, [selectedJob, partRequests]);

  // เมื่อเลือกงานซ่อม ให้ prefill ค่าแรงประเมิน และดึงอะไหล่ที่อนุมัติแล้วเข้าบิลให้อัตโนมัติทันที
  useEffect(() => {
    if (!selectedJob) {
      setItems([]);
      setIsWarrantyCovered(false);
      setWarrantyStatusText(null);
      return;
    }

    const initial = [];
    const estimatedPrice = Number(selectedJob.estimated_price) || 0;
    if (estimatedPrice > 0) {
      initial.push({ key: "estimated_labor", name: "ค่าแรง (ราคาประเมินจากช่าง)", qty: 1, price: estimatedPrice });
    }

    // นำรายการอะไหล่ที่อนุมัติแล้วใส่ลงในตารางบิลให้อัตโนมัติ
    const jobApprovedParts = (partRequests || []).filter(
      (pr) => matchesRepairId(pr.repair_id, selectedJob) && pr.status === "อนุมัติแล้ว"
    );
    jobApprovedParts.forEach((pr) => {
      initial.push({
        key: `part_req_${pr.id}`,
        name: pr.part_name || "อะไหล่",
        qty: Number(pr.quantity) || 1,
        price: priceForPartId(pr.part_id),
        sourceRequestId: pr.id,
      });
    });

    setItems(initial);
    setDiscount("");
    setIncludeVat(true);
    setEnableWht(false);
    setWhtRate(3);

    const machine = selectedJob.machine_id != null ? machineById.get(String(selectedJob.machine_id)) : null;
    const info = getMachineWarrantyInfo(machine);
    setIsWarrantyCovered(info.active);
    setWarrantyStatusText(machine ? info.statusText : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedJob?.id]);

  const subtotal = items.reduce((sum, it) => sum + (Number(it.qty) || 0) * (Number(it.price) || 0), 0);
  const discountAmount = Math.min(Number(discount) || 0, subtotal);
  const subtotalAfterDiscount = subtotal - discountAmount;
  const vatAmount = includeVat ? subtotalAfterDiscount * 0.07 : 0;
  const whtAmount = enableWht ? subtotalAfterDiscount * (whtRate / 100) : 0;
  const grandTotal = subtotalAfterDiscount + vatAmount - whtAmount;
  const addedRequestIds = new Set(items.filter((it) => it.sourceRequestId).map((it) => it.sourceRequestId));

  function addPartRequestItem(pr) {
    setItems((prev) => [
      ...prev,
      {
        key: `part_req_${pr.id}`,
        name: pr.part_name || "อะไหล่",
        qty: Number(pr.quantity) || 1,
        price: priceForPartId(pr.part_id),
        sourceRequestId: pr.id,
      },
    ]);
  }

  function addBlankItem() {
    setItems((prev) => [...prev, { key: `custom_${Date.now()}`, name: "", qty: 1, price: 0 }]);
  }

  function updateItem(key, patch) {
    setItems((prev) => prev.map((it) => (it.key === key ? { ...it, ...patch } : it)));
  }

  function removeItem(key) {
    setItems((prev) => prev.filter((it) => it.key !== key));
  }

  async function handleSave() {
    if (!selectedJob || items.length === 0) return;
    setSaving(true);
    try {
      const invoiceNo = await nextInvoiceNumber();
      const cleanItems = items
        .filter((it) => it.name.trim())
        .map((it) => ({
          name: it.name.trim(),
          qty: Number(it.qty) || 0,
          price: Number(it.price) || 0,
          subtotal: (Number(it.qty) || 0) * (Number(it.price) || 0),
        }));

      const cleanSubtotal = cleanItems.reduce((sum, it) => sum + it.subtotal, 0);
      const cleanDiscount = Math.min(Number(discount) || 0, cleanSubtotal);
      const cleanAfterDiscount = cleanSubtotal - cleanDiscount;
      const cleanVat = includeVat ? cleanAfterDiscount * 0.07 : 0;
      const cleanWht = enableWht ? cleanAfterDiscount * (whtRate / 100) : 0;
      const total = cleanAfterDiscount + cleanVat - cleanWht;

      const updates = {
        total_price: total,
        invoiced_at: new Date().toISOString(),
        invoice_no: invoiceNo,
        invoice_items: cleanItems,
        invoice_subtotal: cleanSubtotal,
        invoice_discount: cleanDiscount,
        invoice_vat_amount: cleanVat,
        invoice_wht_amount: cleanWht,
        is_warranty_covered: isWarrantyCovered,
        is_paid: isWarrantyCovered ? 1 : 0,
      };
      if (isWarrantyCovered) {
        updates.receipt_no = `WARRANTY-${invoiceNo}`;
      }
      await updateRow("repairs", selectedJob.id, updates);

      // มาร์กคำขอเบิกอะไหล่ที่ดึงเข้าบิลแล้วว่า "ออกบิลแล้ว"
      await Promise.all(
        items
          .filter((it) => it.sourceRequestId)
          .map((it) =>
            updateRow("part_requests", it.sourceRequestId, { status: "ออกบิลแล้ว" }).catch((err) =>
              console.error("[FinancePage] mark part request billed failed:", err)
            )
          )
      );

      const admin = getSessionAdmin();
      logActivity({
        adminUsername: admin?.username,
        adminName: admin?.admin_name,
        action: "ออกใบแจ้งหนี้",
        target: `${invoiceNo} · ${selectedJob.ticketNo || `#${selectedJob.id}`} · ${total.toLocaleString("th-TH")} บาท`,
      }).catch((err) => console.error("[FinancePage] log activity failed:", err));
      onClose();
    } catch (err) {
      console.error("[FinancePage] create invoice failed:", err);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      title="ออกใบแจ้งหนี้ใหม่"
      onClose={onClose}
      wide
      footer={
        <>
          <button onClick={onClose} className="px-4 py-2 rounded-xl text-sm text-slate-500 hover:bg-slate-50">
            ยกเลิก
          </button>
          <PrimaryButton onClick={handleSave} disabled={!selectedJob || items.length === 0 || saving}>
            {saving ? "กำลังบันทึก..." : "ออกใบแจ้งหนี้"}
          </PrimaryButton>
        </>
      }
    >
      <div>
        <label className="text-sm text-slate-600 mb-2 block font-medium">
          เลือกงานซ่อม <span className="text-red-400">*</span>
        </label>
        <select
          value={repairId}
          onChange={(e) => setRepairId(e.target.value)}
          className="w-full px-4 py-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[15px] text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-100"
        >
          <option value="">เลือกงานที่พร้อมออกบิล (มีราคาประเมินและอนุมัติอะไหล่แล้ว)...</option>
          {invoiceableJobs.map((r) => (
            <option key={r.id} value={r.id}>
              {r.ticketNo || `#${r.id}`} — {r.customer_username || "-"} ({r.machine || "-"}) [ประเมิน: {Number(r.estimated_price).toLocaleString("th-TH")} บาท]
            </option>
          ))}
        </select>
        {invoiceableJobs.length === 0 ? (
          <p className="text-xs text-slate-400 mt-2">
            ไม่มีงานที่พร้อมออกบิลตอนนี้ (ต้องเป็นงานที่ช่างกรอกราคาประเมิน และมีคำขอเบิกอะไหล่ที่แอดมินอนุมัติครบแล้ว)
          </p>
        ) : null}
      </div>

      {selectedJob ? (
        <>
          <div className="rounded-xl border border-slate-100 p-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isWarrantyCovered}
                onChange={(e) => setIsWarrantyCovered(e.target.checked)}
                className="rounded border-slate-300"
              />
              <span className="text-sm font-medium text-slate-700">อยู่ในประกัน (ลูกค้าไม่ต้องชำระเงิน)</span>
            </label>
            <p className="text-xs text-slate-400 mt-1.5 ml-6">
              {warrantyStatusText
                ? `ตรวจสอบจากข้อมูลเครื่องจักร: ${warrantyStatusText}`
                : "ไม่พบข้อมูลประกันของเครื่องจักรนี้ในระบบ — เลือกเองได้ถ้าทราบว่ายังอยู่ในประกัน"}
            </p>
          </div>

          <div className="rounded-xl border border-slate-100 p-4">
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs font-semibold text-slate-500">รายการในบิล</p>
              <button
                onClick={addBlankItem}
                className="flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-700"
              >
                <Plus size={13} /> เพิ่มรายการเอง
              </button>
            </div>
            {items.length === 0 ? (
              <p className="text-xs text-slate-400 py-2">ยังไม่มีรายการในบิล — เพิ่มจากคำขอเบิกด้านล่าง หรือกด "เพิ่มรายการเอง"</p>
            ) : (
              <div className="space-y-2">
                {items.map((it) => (
                  <div key={it.key} className="flex items-center gap-2">
                    <input
                      type="text"
                      value={it.name}
                      onChange={(e) => updateItem(it.key, { name: e.target.value })}
                      placeholder="ชื่อรายการ"
                      className="flex-1 min-w-0 px-3 py-2 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-700"
                    />
                    <input
                      type="number"
                      value={it.qty}
                      onChange={(e) => updateItem(it.key, { qty: e.target.value })}
                      className="w-16 px-2 py-2 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-700 text-center"
                      title="จำนวน"
                    />
                    <input
                      type="number"
                      value={it.price}
                      onChange={(e) => updateItem(it.key, { price: e.target.value })}
                      className="w-24 px-2 py-2 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-700 text-right"
                      title="ราคา/หน่วย"
                    />
                    <span className="w-24 shrink-0 text-right text-sm font-medium text-slate-700">
                      {((Number(it.qty) || 0) * (Number(it.price) || 0)).toLocaleString("th-TH")}
                    </span>
                    <button onClick={() => removeItem(it.key)} className="text-red-400 hover:text-red-600 shrink-0">
                      <Trash2 size={15} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {availablePartRequests.length > 0 ? (
            <div className="rounded-xl border border-slate-100 p-4">
              <p className="text-xs font-semibold text-slate-500 mb-2">คำขอเบิกอะไหล่ที่อนุมัติแล้ว</p>
              <div className="space-y-1.5">
                {availablePartRequests.map((pr) => {
                  const added = addedRequestIds.has(pr.id);
                  return (
                    <div key={pr.id} className="flex items-center justify-between text-sm gap-2">
                      <span className="text-slate-600">
                        {pr.part_name} × {pr.quantity} ({priceForPartId(pr.part_id).toLocaleString("th-TH")} บาท/ชิ้น)
                      </span>
                      <button
                        onClick={() => addPartRequestItem(pr)}
                        disabled={added}
                        className={`shrink-0 text-xs font-medium px-2.5 py-1 rounded-lg ${
                          added ? "bg-slate-50 text-slate-300" : "bg-blue-50 text-blue-600 hover:bg-blue-100"
                        }`}
                      >
                        {added ? "เพิ่มแล้ว" : "+ เพิ่มเข้าบิล"}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : null}

          <div className="rounded-xl border border-slate-100 p-4 space-y-3">
            <div>
              <label className="text-xs font-medium text-slate-500 mb-1 block">ส่วนลด (บาท)</label>
              <input
                type="number"
                value={discount}
                onChange={(e) => setDiscount(e.target.value)}
                placeholder="0"
                className="w-full px-3 py-2 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-700 placeholder:text-slate-400"
              />
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeVat}
                onChange={(e) => setIncludeVat(e.target.checked)}
                className="rounded border-slate-300"
              />
              <span className="text-sm text-slate-700">ภาษีมูลค่าเพิ่ม (VAT 7%)</span>
            </label>
            <div>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={enableWht}
                  onChange={(e) => setEnableWht(e.target.checked)}
                  className="rounded border-slate-300"
                />
                <span className="text-sm text-slate-700">หักภาษี ณ ที่จ่าย</span>
              </label>
              {enableWht ? (
                <select
                  value={whtRate}
                  onChange={(e) => setWhtRate(Number(e.target.value))}
                  className="mt-2 ml-6 px-3 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-700"
                >
                  <option value={1}>1% (ขนส่ง)</option>
                  <option value={2}>2% (โฆษณา)</option>
                  <option value={3}>3% (บริการ)</option>
                  <option value={5}>5% (ค่าเช่า)</option>
                </select>
              ) : null}
            </div>
          </div>

          <div className="rounded-xl bg-blue-50 px-4 py-3 space-y-1.5">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-500">รวมรายการ</span>
              <span className="text-slate-700">{subtotal.toLocaleString("th-TH")} บาท</span>
            </div>
            {discountAmount > 0 ? (
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">ส่วนลด</span>
                <span className="text-red-500">-{discountAmount.toLocaleString("th-TH")} บาท</span>
              </div>
            ) : null}
            {includeVat ? (
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">VAT 7%</span>
                <span className="text-slate-700">+{vatAmount.toLocaleString("th-TH")} บาท</span>
              </div>
            ) : null}
            {enableWht ? (
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">หัก ณ ที่จ่าย {whtRate}%</span>
                <span className="text-red-500">-{whtAmount.toLocaleString("th-TH")} บาท</span>
              </div>
            ) : null}
            <div className="flex items-center justify-between pt-1.5 border-t border-blue-100">
              <span className="text-sm font-medium text-blue-700">ยอดรวมทั้งหมด</span>
              <span className="text-lg font-semibold text-blue-700">{grandTotal.toLocaleString("th-TH")} บาท</span>
            </div>
          </div>
          {isWarrantyCovered ? (
            <p className="text-xs text-emerald-600 -mt-2">ลูกค้าไม่ต้องชำระเงิน (อยู่ในประกัน)</p>
          ) : null}
        </>
      ) : null}
    </Modal>
  );
}

function formatCustomerAddress(c) {
  if (!c) return "-";
  const parts = [
    c.house_no,
    c.moo ? `หมู่ ${c.moo}` : "",
    c.tambon ? `ตำบล${c.tambon}` : "",
    c.amphoe ? `อำเภอ${c.amphoe}` : "",
    c.changwat ? `จังหวัด${c.changwat}` : "",
    c.postal_code,
  ].filter(Boolean);
  return parts.length > 0 ? parts.join(" ") : "-";
}

function InvoiceModal({ repair, customer, companySettings, onClose }) {
  const items = Array.isArray(repair.invoice_items) ? repair.invoice_items : [];
  const laborCost = Number(repair.labor_cost) || 0;
  const total = Number(repair.total_price) || 0;
  const subtotal = Number(repair.invoice_subtotal) || 0;
  const discount = Number(repair.invoice_discount) || 0;
  const vatAmount = Number(repair.invoice_vat_amount) || 0;
  const whtAmount = Number(repair.invoice_wht_amount) || 0;
  const hasBreakdown = subtotal > 0;
  const isPaid = repair.is_paid === 1 || repair.is_paid === true;
  const isWarrantyCovered = repair.is_warranty_covered === true || repair.is_warranty_covered === 1;
  const issuedDate = repair.invoiced_at ? new Date(repair.invoiced_at) : null;
  const dateLabel = issuedDate ? formatDateBySetting(issuedDate) : "-";
  const customerName = customer ? [customer.name, customer.surname].filter(Boolean).join(" ") || customer.username : repair.customer_username || "-";

  return (
    <Modal
      title="ใบแจ้งหนี้"
      onClose={onClose}
      wide
      footer={
        <>
          <button onClick={onClose} className="px-4 py-2 rounded-xl text-sm text-slate-500 hover:bg-slate-50">
            ปิด
          </button>
          <button
            onClick={() => window.print()}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-white"
            style={{ background: "#B22121" }}
          >
            <Printer size={15} />
            พิมพ์ / บันทึกเป็น PDF
          </button>
        </>
      }
    >
      <style>{`
        @media print {
          body * { visibility: hidden; }
          #print-invoice-area, #print-invoice-area * { visibility: visible; }
          #print-invoice-area {
            position: fixed;
            inset: 0;
            width: 100%;
            height: auto;
            overflow: visible;
            padding: 24px;
            margin: 0;
          }
        }
      `}</style>

      <div id="print-invoice-area" className="text-slate-800">
        <div className="flex items-start justify-between mb-6 pb-4 border-b border-slate-200">
          <div>
            <h1 className="text-lg font-bold" style={{ color: "#B22121" }}>{companySettings?.companyName || "ระบบแจ้งซ่อม After Sales"}</h1>
            {companySettings?.companyPhone ? <p className="text-xs text-slate-400 mt-1">โทร {companySettings.companyPhone}</p> : null}
            {companySettings?.companyEmail ? <p className="text-xs text-slate-400">{companySettings.companyEmail}</p> : null}
          </div>
          <div className="text-right">
            <p className="text-base font-bold text-slate-800">ใบแจ้งหนี้</p>
            <p className="text-sm text-slate-500 mt-0.5">{repair.invoice_no || "-"}</p>
            <p className="text-xs text-slate-400 mt-1">วันที่ {dateLabel}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1">ลูกค้า</p>
            <p className="text-sm font-medium text-slate-800">{customerName}</p>
            {customer?.company ? <p className="text-xs text-slate-500">{customer.company}</p> : null}
            <p className="text-xs text-slate-500 mt-1">{formatCustomerAddress(customer)}</p>
            {customer?.phone ? <p className="text-xs text-slate-500 mt-1">โทร {customer.phone}</p> : null}
          </div>
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-1">งานซ่อม</p>
            <p className="text-sm font-medium text-slate-800">{repair.ticketNo || `#${repair.id}`}</p>
            <p className="text-xs text-slate-500 mt-1">{repair.machine || "-"}</p>
            <p className="text-xs text-slate-500 mt-1">วันนัดหมาย: {displayStoredDate(repair.date)}</p>
          </div>
        </div>

        <table className="w-full text-sm mb-4">
          <thead>
            <tr className="text-xs text-slate-400 border-b border-slate-200">
              <th className="text-left font-medium py-2">รายการ</th>
              <th className="text-right font-medium py-2">จำนวน</th>
              <th className="text-right font-medium py-2">ราคา/หน่วย</th>
              <th className="text-right font-medium py-2">รวม</th>
            </tr>
          </thead>
          <tbody>
            {items.map((it, i) => (
              <tr key={i} className="border-b border-slate-50">
                <td className="py-2 text-slate-700">{it.name}</td>
                <td className="py-2 text-right text-slate-600">{it.qty}</td>
                <td className="py-2 text-right text-slate-600">{Number(it.price).toLocaleString("th-TH")}</td>
                <td className="py-2 text-right text-slate-700 font-medium">{Number(it.subtotal).toLocaleString("th-TH")}</td>
              </tr>
            ))}
            {laborCost > 0 ? (
              <tr className="border-b border-slate-50">
                <td className="py-2 text-slate-700">ค่าแรง</td>
                <td className="py-2 text-right text-slate-600">-</td>
                <td className="py-2 text-right text-slate-600">-</td>
                <td className="py-2 text-right text-slate-700 font-medium">{laborCost.toLocaleString("th-TH")}</td>
              </tr>
            ) : null}
            {items.length === 0 && laborCost === 0 ? (
              <tr>
                <td colSpan={4} className="py-4 text-center text-xs text-slate-400">ไม่มีรายการ</td>
              </tr>
            ) : null}
          </tbody>
        </table>

        <div className="flex justify-end">
          <div className="w-64">
            {hasBreakdown ? (
              <>
                <div className="flex items-center justify-between py-1 text-sm">
                  <span className="text-slate-500">รวมรายการ</span>
                  <span className="text-slate-700">{subtotal.toLocaleString("th-TH")} บาท</span>
                </div>
                {discount > 0 ? (
                  <div className="flex items-center justify-between py-1 text-sm">
                    <span className="text-slate-500">ส่วนลด</span>
                    <span className="text-red-500">-{discount.toLocaleString("th-TH")} บาท</span>
                  </div>
                ) : null}
                {vatAmount > 0 ? (
                  <div className="flex items-center justify-between py-1 text-sm">
                    <span className="text-slate-500">VAT 7%</span>
                    <span className="text-slate-700">+{vatAmount.toLocaleString("th-TH")} บาท</span>
                  </div>
                ) : null}
                {whtAmount > 0 ? (
                  <div className="flex items-center justify-between py-1 text-sm">
                    <span className="text-slate-500">หัก ณ ที่จ่าย</span>
                    <span className="text-red-500">-{whtAmount.toLocaleString("th-TH")} บาท</span>
                  </div>
                ) : null}
              </>
            ) : null}
            <div className="flex items-center justify-between py-2 border-t border-slate-200">
              <span className="text-sm font-semibold text-slate-700">ยอดรวมทั้งหมด</span>
              <span className="text-base font-bold" style={{ color: "#B22121" }}>฿{total.toLocaleString("th-TH", { maximumFractionDigits: 0 })}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-500">สถานะการชำระ</span>
              <span className={`text-xs font-semibold ${isWarrantyCovered || isPaid ? "text-emerald-600" : "text-orange-500"}`}>
                {isWarrantyCovered ? "ไม่มีค่าใช้จ่าย (อยู่ในประกัน)" : isPaid ? "ชำระแล้ว" : "ยังไม่ชำระ"}
              </span>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
}

export default function FinancePage() {
  const { data: repairs, loading } = useDbList("repairs");
  const { data: partRequests } = useDbList("part_requests");
  const { data: spareParts } = useDbList("spare_parts");
  const { data: customers } = useDbList("customers");
  const { data: machines } = useDbList("machines");
  const [creatingInvoice, setCreatingInvoice] = useState(false);
  const [viewingInvoice, setViewingInvoice] = useState(null);
  const [viewingSlip, setViewingSlip] = useState(null);
  const [companySettings, setCompanySettings] = useState(null);
  const { settings: webSettings } = useWebSettings();

  useEffect(() => {
    getWebSettings()
      .then(setCompanySettings)
      .catch((err) => console.error("[FinancePage] load settings failed:", err));
  }, []);

  const invoiced = repairs.filter((r) => Number(r.total_price) > 0);
  const isWarrantyRow = (r) => r.is_warranty_covered === true || r.is_warranty_covered === 1;
  const paid = invoiced.filter((r) => !isWarrantyRow(r) && (r.is_paid === 1 || r.is_paid === true));
  const unpaid = invoiced.filter((r) => !isWarrantyRow(r) && !(r.is_paid === 1 || r.is_paid === true));

  const totalRevenue = paid.reduce((sum, r) => sum + (Number(r.total_price) || 0), 0);
  const totalUnpaid = unpaid.reduce((sum, r) => sum + (Number(r.total_price) || 0), 0);

  async function markAsPaid(repair) {
    try {
      await updateRow("repairs", repair.id, { is_paid: 1, payment_overdue_notified: 0 });
      const admin = getSessionAdmin();
      logActivity({
        adminUsername: admin?.username,
        adminName: admin?.admin_name,
        action: "มาร์กว่าชำระแล้ว",
        target: `${repair.ticketNo || `#${repair.id}`} · ${(Number(repair.total_price) || 0).toLocaleString("th-TH")} บาท`,
      }).catch((err) => console.error("[FinancePage] log activity failed:", err));
    } catch (err) {
      console.error("[FinancePage] mark as paid failed:", err);
    }
  }

  const sorted = [...invoiced].sort((a, b) => (b.created_at || "").localeCompare(a.created_at || ""));
  const pageSize = Number(webSettings.itemsPerPageFinance) || 20;
  const [page, setPage] = useState(1);
  useEffect(() => {
    setPage(1);
  }, [sorted.length]);
  const totalPages = Math.max(1, Math.ceil(sorted.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const paged = sorted.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  return (
    <div>
      <div className="flex justify-end mb-5">
        <PrimaryButton icon={Plus} onClick={() => setCreatingInvoice(true)}>
          ออกใบแจ้งหนี้ใหม่
        </PrimaryButton>
      </div>

      <div className="flex flex-wrap gap-4 mb-5">
        <div className="bg-white rounded-2xl border border-slate-100 p-4 flex-1 min-w-[200px]">
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-9 h-9 rounded-xl ${COLORS.green.bg} ${COLORS.green.text} flex items-center justify-center`}>
              <CheckCircle2 size={18} />
            </div>
            <span className="text-sm text-slate-500">รายได้ที่ชำระแล้ว</span>
          </div>
          <span className="text-2xl font-semibold text-slate-900">{totalRevenue.toLocaleString("th-TH")} บาท</span>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-4 flex-1 min-w-[200px]">
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-9 h-9 rounded-xl ${COLORS.orange.bg} ${COLORS.orange.text} flex items-center justify-center`}>
              <Clock size={18} />
            </div>
            <span className="text-sm text-slate-500">ยอดค้างชำระ</span>
          </div>
          <span className="text-2xl font-semibold text-slate-900">{totalUnpaid.toLocaleString("th-TH")} บาท</span>
        </div>

        <div className="bg-white rounded-2xl border border-slate-100 p-4 flex-1 min-w-[200px]">
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-9 h-9 rounded-xl ${COLORS.blue.bg} ${COLORS.blue.text} flex items-center justify-center`}>
              <Wallet size={18} />
            </div>
            <span className="text-sm text-slate-500">ใบแจ้งหนี้ทั้งหมด</span>
          </div>
          <span className="text-2xl font-semibold text-slate-900">{invoiced.length} ใบ</span>
        </div>
      </div>

      <Card className="p-0 overflow-hidden">
        <div className="p-5">
          {loading ? (
            <p className="text-xs text-slate-400 text-center py-8">กำลังโหลดข้อมูล...</p>
          ) : sorted.length === 0 ? (
            <EmptyState icon={Wallet} message="ยังไม่มีใบแจ้งหนี้ในระบบ" />
          ) : (
            <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="text-xs text-slate-400 border-b border-slate-100">
                  <th className="py-2 font-medium">เลขที่ใบแจ้งหนี้</th>
                  <th className="py-2 font-medium">Job ID</th>
                  <th className="py-2 font-medium">ลูกค้า</th>
                  <th className="py-2 font-medium">ยอดรวม</th>
                  <th className="py-2 font-medium">สถานะ</th>
                  <th className="py-2 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {paged.map((r) => {
                  const isPaid = r.is_paid === 1 || r.is_paid === true;
                  const state = getPaymentState(r);
                  const badgeText =
                    state === "warranty"
                      ? "ไม่มีค่าใช้จ่าย (ประกัน)"
                      : state === "paid"
                      ? "ชำระแล้ว"
                      : state === "awaiting"
                      ? "รอตรวจสอบสลิป"
                      : "ยังไม่ชำระ";
                  const badgeClass =
                    state === "warranty"
                      ? "bg-emerald-50 text-emerald-600"
                      : state === "paid"
                      ? "bg-emerald-50 text-emerald-600"
                      : state === "awaiting"
                      ? "bg-blue-50 text-blue-600"
                      : "bg-orange-50 text-orange-600";
                  return (
                    <tr key={r.id} className="border-b border-slate-50 last:border-0">
                      <td className="py-2.5 text-slate-500">{r.invoice_no || "-"}</td>
                      <td className="py-2.5 text-slate-700">{r.ticketNo || r.id}</td>
                      <td className="py-2.5 text-slate-700">{r.customer_username || "-"}</td>
                      <td className="py-2.5 text-slate-700">{Number(r.total_price || 0).toLocaleString("th-TH")} บาท</td>
                      <td className="py-2.5">
                        <span className={`inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full ${badgeClass}`}>
                          {state === "warranty" ? <ShieldCheck size={11} /> : null}
                          {badgeText}
                        </span>
                      </td>
                      <td className="py-2.5 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {r.invoice_no ? (
                            <button
                              onClick={() => setViewingInvoice(r)}
                              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-50 text-slate-600 text-xs font-medium hover:bg-slate-100"
                            >
                              <FileText size={13} /> ดูใบแจ้งหนี้
                            </button>
                          ) : null}
                          {r.customer_payment_slip ? (
                            <button
                              onClick={() => setViewingSlip(r)}
                              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 text-xs font-medium hover:bg-blue-100"
                            >
                              <Receipt size={13} /> ดูสลิป
                            </button>
                          ) : null}
                          {!isPaid && state !== "warranty" ? (
                            <button
                              onClick={() => markAsPaid(r)}
                              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-600 text-xs font-medium hover:bg-emerald-100"
                            >
                              <Check size={13} /> มาร์กว่าชำระแล้ว
                            </button>
                          ) : null}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            </div>
          )}
          <Pagination
            page={currentPage}
            totalPages={totalPages}
            onChange={setPage}
            totalItems={sorted.length}
            pageSize={pageSize}
          />
        </div>
      </Card>

      {creatingInvoice ? (
        <CreateInvoiceModal
          repairs={repairs}
          partRequests={partRequests}
          spareParts={spareParts}
          machines={machines}
          onClose={() => setCreatingInvoice(false)}
        />
      ) : null}

      {viewingInvoice ? (
        <InvoiceModal
          repair={viewingInvoice}
          customer={customers.find((c) => c.username === viewingInvoice.customer_username)}
          companySettings={companySettings}
          onClose={() => setViewingInvoice(null)}
        />
      ) : null}

      {viewingSlip ? (
        <Modal
          title={`สลิปโอนเงิน — ${viewingSlip.ticketNo || `#${viewingSlip.id}`}`}
          onClose={() => setViewingSlip(null)}
          footer={
            <>
              <button
                onClick={() => setViewingSlip(null)}
                className="px-4 py-2 rounded-xl text-sm text-slate-500 hover:bg-slate-50"
              >
                ปิด
              </button>
              {!(viewingSlip.is_paid === 1 || viewingSlip.is_paid === true) ? (
                <PrimaryButton
                  icon={Check}
                  onClick={() => {
                    markAsPaid(viewingSlip);
                    setViewingSlip(null);
                  }}
                >
                  มาร์กว่าชำระแล้ว
                </PrimaryButton>
              ) : null}
            </>
          }
        >
          <div className="flex flex-col items-center">
            <img
              src={viewingSlip.customer_payment_slip}
              alt="สลิปโอนเงิน"
              className="max-h-[70vh] w-auto rounded-xl border border-slate-100"
            />
            <p className="text-xs text-slate-400 mt-3">
              ยอดที่ต้องชำระ: {Number(viewingSlip.total_price || 0).toLocaleString("th-TH")} บาท
            </p>
          </div>
        </Modal>
      ) : null}
    </div>
  );
}