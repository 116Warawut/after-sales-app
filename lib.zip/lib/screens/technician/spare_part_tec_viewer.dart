import 'package:after_sales/app_styles.dart';
import 'package:flutter/material.dart';
import 'package:after_sales/services.dart' as db;
import 'package:after_sales/utils/firebase_number.dart';
import 'package:after_sales/widgets.dart';

// ==========================================
// 1. Data Model — รับข้อมูลจริงจากตาราง spare_parts
// ==========================================
class PartItem {
  final int id;
  final String partName;
  final String partCode;
  final int stock; // จำนวนคงเหลือจริง — โชว์เฉพาะตอนเปิดดูรายละเอียด
  final bool isAvailable; // true = มี (stock > 0), false = หมด
  // 📷 [แก้ไข] เพิ่ม photoUrl — เดิมโมเดลนี้ไม่ได้อ่านฟิลด์นี้จาก Firebase เลย
  // ทำให้ต่อให้แอดมินอัปโหลดรูปไว้แล้ว หน้าเบิกของช่างก็ยังโชว์แต่ไอคอนเดิม
  final String photoUrl;
  // 💰 [ใหม่] ราคาต่อหน่วย — เดิมโมเดลนี้ไม่มีฟิลด์นี้เลย ทั้งที่ตาราง
  // spare_parts เก็บฟิลด์ 'price' ไว้อยู่แล้ว (หน้าเว็บอ่านฟิลด์เดียวกันนี้ไป
  // แสดงผลปกติ) ทำให้หน้าเบิกของช่างไม่เคยโชว์ราคาให้เห็นเลย
  final double price;
  // 🐛 [แก้บัค] key ที่ใช้อ้างอิงในตะกร้าเบิก (_cart) — เดิมใช้ part.id ตรงๆ
  // แต่ข้อมูลอะไหล่บางส่วนใน Firebase มีฟิลด์ 'id' เป็น 0 ซ้ำกันหลายรายการ (ข้อมูล
  // เก่า/ย้ายมาจาก SQLite ที่ไม่ได้เซ็ต id ให้ครบ) ทำให้ทุกชิ้นที่ id=0 ไปชนกันใน
  // ตะกร้าเป็นแถวเดียวกันหมด — เลือกชิ้นไหนก็เด้งขอบแดงทุกชิ้น และเพิ่มอะไหล่ชิ้นที่
  // สองไม่ได้เพราะไปทับชิ้นแรกในตะกร้าตลอด ใช้ cartKey จาก Firebase key ของแถว
  // นั้นแทน (_fbKey) ซึ่งไม่มีทางซ้ำกันได้ไม่ว่าฟิลด์ id ภายในจะถูกต้องหรือไม่
  final String cartKey;

  PartItem({
    required this.id,
    required this.partName,
    required this.partCode,
    required this.stock,
    required this.isAvailable,
    this.photoUrl = '',
    this.price = 0,
    required this.cartKey,
  });

  factory PartItem.fromMap(Map<String, dynamic> map) {
    final stock = toIntOr(map['stock'], 0);
    final id = toIntOr(map['id'], 0);
    // ลำดับความสำคัญ: Firebase key จริงของแถว (ไม่ซ้ำแน่นอน) > id ตัวเลข (ถ้า
    // มากกว่า 0 แปลว่าน่าเชื่อถือ) > รหัสอะไหล่ (กันเหนียวสุดท้ายถ้าข้อมูลแปลกมาก)
    final fbKey = map['_fbKey']?.toString();
    final cartKey = (fbKey != null && fbKey.isNotEmpty)
        ? fbKey
        : (id > 0 ? id.toString() : (map['part_code']?.toString() ?? ''));
    return PartItem(
      id: id,
      partName: (map['part_name']?.toString()) ?? '-',
      partCode: (map['part_code']?.toString()) ?? '-',
      stock: stock,
      isAvailable: stock > 0,
      // ⭐ ใช้ key เดียวกับที่แอดมินบันทึกไว้ ('photo_url')
      photoUrl: (map['photo_url']?.toString()) ?? '',
      price: toDoubleOr(map['price'], 0),
      cartKey: cartKey,
    );
  }
}

/// รายการอะไหล่ 1 ชิ้นที่อยู่ในตะกร้าเบิก (ยังไม่ได้ยืนยัน)
class _CartLine {
  final PartItem part;
  int quantity;
  _CartLine({required this.part, this.quantity = 1});
}

// ==========================================
// 2. หน้าจอหลัก (UI)
// ==========================================
class RequestPartScreen extends StatefulWidget {
  /// ถ้าเปิดมาจากหน้ารายละเอียดงานซ่อม จะส่ง id งานนั้นมาด้วย เพื่อผูกอะไหล่ที่เบิก
  /// เข้ากับงานนี้โดยเฉพาะ (ใช้ดึงมาออกบิลได้ทีหลัง) ถ้าเปิดจากเมนูทั่วไปจะเป็น null
  final int? repairId;

  const RequestPartScreen({super.key, this.repairId});

  @override
  State<RequestPartScreen> createState() => _RequestPartScreenState();
}

class _RequestPartScreenState extends State<RequestPartScreen> {
  bool _loading = true;
  List<PartItem> _allParts = [];
  String _query = '';

  // 🐛 [แก้บัค] เดิมไม่มีตัวกันกดซ้ำตอนกดยืนยันเบิกของ — ปุ่ม "ยืนยันเบิก" ที่
  // แถบล่างค้างจอ กับปุ่ม "ยืนยันการเบิกอะไหล่ทั้งหมด" ในชีตตะกร้า เรียก
  // _submitCart() ตรง ๆ ทั้งคู่ ถ้ากดรัว/กดสองปุ่มไล่กันก่อนที่ฟังก์ชันจะเคลียร์
  // ตะกร้า (_cart.clear() ทำหลัง insert เสร็จหมดแล้วเท่านั้น) จะวน insert
  // รายการเดิมซ้ำ 2 รอบ กลายเป็นคำขอเบิกซ้ำ (เช่นเบิกของ 4 ชิ้น กลายเป็น 8
  // รายการ) — เพิ่มธงกันกดซ้ำ ปิดปุ่มไว้ระหว่างที่กำลังส่งคำขออยู่
  bool _isSubmittingCart = false;

  // 🛒 ตะกร้าเบิกอะไหล่ — key เป็น part.cartKey (Firebase key จริง) กันเผลอเพิ่ม
  // ชิ้นเดียวกันซ้ำเป็นแถวใหม่ และกันชิ้นที่ id ในฐานข้อมูลชนกันแล้วไปทับกันเอง
  final Map<String, _CartLine> _cart = {};

  @override
  void initState() {
    super.initState();
    _loadParts();
  }

  Future<void> _loadParts() async {
    setState(() => _loading = true);
    try {
      final rows = await db.DatabaseHelper.instance.getSpareParts();
      if (!mounted) return;
      setState(() {
        _allParts = rows.map((row) => PartItem.fromMap(row)).toList();
        _loading = false;
      });
    } catch (e) {
      debugPrint('Error loading spare parts: $e');
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  List<PartItem> get _filteredParts {
    if (_query.trim().isEmpty) return _allParts;
    final q = _query.trim().toLowerCase();
    return _allParts.where((p) {
      return p.partName.toLowerCase().contains(q) ||
          p.partCode.toLowerCase().contains(q);
    }).toList();
  }

  int get _cartCount =>
      _cart.values.fold(0, (sum, line) => sum + line.quantity);

  void _snack(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(fontFamily: AppStyles.fontFamily),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------
  // 🧾 เปิด popup รายละเอียดอะไหล่ + เลือกจำนวนที่จะเบิก
  // ---------------------------------------------------------------------
  void _openPartDetail(PartItem part) {
    int quantity = _cart[part.cartKey]?.quantity ?? 1;
    if (quantity > part.stock && part.stock > 0) quantity = part.stock;
    bool showStockWarning = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheetState) {
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(sheetContext).viewInsets.bottom,
              ),
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 16),
                        decoration: BoxDecoration(
                          color: AppColors.border,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),

                    // 🖼️ [แก้ไข] รูปจริงจาก photo_url + ชื่อ/รหัส/สถานะ
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: LocalOrNetworkImage(
                            path: part.photoUrl,
                            width: 64,
                            height: 64,
                            fit: BoxFit.cover,
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                part.partName,
                                style: const TextStyle(
                                  fontFamily: AppStyles.fontFamily,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.textMain,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'รหัส : ${part.partCode}',
                                style: const TextStyle(
                                  fontFamily: AppStyles.fontFamily,
                                  fontSize: 13,
                                  color: AppColors.textSubtitle,
                                ),
                              ),
                              const SizedBox(height: 4),
                              // 💰 [ใหม่] โชว์ราคาต่อหน่วยในหน้ารายละเอียดด้วย
                              Text(
                                '${part.price.toStringAsFixed(0)} บาท / ชิ้น',
                                style: const TextStyle(
                                  fontFamily: AppStyles.fontFamily,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.primary,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: part.isAvailable
                                          ? AppColors.greenBg
                                          : AppColors.redBg,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      part.isAvailable ? 'มีสต๊อก' : 'หมดสต๊อก',
                                      style: TextStyle(
                                        fontFamily: AppStyles.fontFamily,
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700,
                                        color: part.isAvailable
                                            ? AppColors.greenText
                                            : AppColors.redText,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    'คงเหลือ ${part.stock} ชิ้น',
                                    style: const TextStyle(
                                      fontFamily: AppStyles.fontFamily,
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.textSubtitle,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 20),
                    const Divider(height: 1, color: AppColors.border),
                    const SizedBox(height: 16),

                    // 🔢 ตัวเลือกจำนวน — กดได้เฉพาะตอนมีสต๊อก
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'จำนวนที่จะเบิก',
                          style: TextStyle(
                            fontFamily: AppStyles.fontFamily,
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: part.isAvailable
                                ? AppColors.textMain
                                : AppColors.textHint,
                          ),
                        ),
                        Row(
                          children: [
                            _StepperButton(
                              icon: Icons.remove,
                              enabled: part.isAvailable && quantity > 1,
                              onTap: () => setSheetState(() {
                                quantity--;
                                showStockWarning = false;
                              }),
                            ),
                            SizedBox(
                              width: 40,
                              child: Text(
                                '$quantity',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontFamily: AppStyles.fontFamily,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w700,
                                  color: part.isAvailable
                                      ? AppColors.textMain
                                      : AppColors.textHint,
                                ),
                              ),
                            ),
                            _StepperButton(
                              icon: Icons.add,
                              enabled: part.isAvailable,
                              onTap: () => setSheetState(() {
                                // 🚫 กดเกินจำนวนคงเหลือในคลัง — เตือนแทนที่จะเพิ่มให้เงียบ ๆ
                                if (quantity >= part.stock) {
                                  showStockWarning = true;
                                } else {
                                  quantity++;
                                  showStockWarning = false;
                                }
                              }),
                            ),
                          ],
                        ),
                      ],
                    ),
                    if (showStockWarning) ...[
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(Icons.error_outline,
                              size: 16, color: AppColors.redText),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              'จำนวนอะไหล่ไม่เพียงพอต่อการเบิก (คงเหลือ ${part.stock} ชิ้น)',
                              style: const TextStyle(
                                fontFamily: AppStyles.fontFamily,
                                fontSize: 12,
                                color: AppColors.redText,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                    const SizedBox(height: 20),

                    // ➕ ปุ่มเพิ่มลงตะกร้า — เทาและกดไม่ได้ถ้าอะไหล่หมด
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: part.isAvailable
                              ? AppColors.primary
                              : AppColors.border,
                          foregroundColor: part.isAvailable
                              ? Colors.white
                              : AppColors.textHint,
                          elevation: 0,
                          padding:
                              const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        onPressed: part.isAvailable
                            ? () {
                                Navigator.pop(sheetContext);
                                _addToCart(part, quantity);
                              }
                            : null,
                        icon: Icon(
                          part.isAvailable
                              ? Icons.add_shopping_cart
                              : Icons.block,
                          size: 18,
                        ),
                        label: Text(
                          part.isAvailable
                              ? 'เพิ่มลงตะกร้าเบิก'
                              : 'อะไหล่หมด ไม่สามารถเบิกได้',
                          style: const TextStyle(
                            fontFamily: AppStyles.fontFamily,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _addToCart(PartItem part, int quantity) {
    if (quantity > part.stock) {
      _snack('จำนวนอะไหล่ไม่เพียงพอต่อการเบิก (คงเหลือ ${part.stock} ชิ้น)');
      return;
    }
    setState(() {
      final existing = _cart[part.cartKey];
      if (existing != null) {
        existing.quantity = quantity;
      } else {
        _cart[part.cartKey] = _CartLine(part: part, quantity: quantity);
      }
    });
    _snack('เพิ่ม "${part.partName}" (จำนวน $quantity) ลงตะกร้าเบิกแล้ว');
  }

  // ---------------------------------------------------------------------
  // 🛒 เปิดตะกร้าเบิกอะไหล่ — ดูรายการที่เลือกไว้ทั้งหมด ก่อนยืนยัน
  // ---------------------------------------------------------------------
  Future<void> _openCart() async {
    if (_cart.isEmpty) {
      _snack('ยังไม่มีอะไหล่ในตะกร้าเบิก');
      return;
    }

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheetState) {
            final lines = _cart.values.toList();
            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(sheetContext).viewInsets.bottom,
              ),
              child: Container(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(sheetContext).size.height * 0.75,
                ),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const SizedBox(height: 12),
                    Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: AppColors.border,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
                      child: Row(
                        children: [
                          const Expanded(
                            child: Text(
                              'ตะกร้าเบิกอะไหล่',
                              style: TextStyle(
                                fontFamily: AppStyles.fontFamily,
                                fontSize: 18,
                                fontWeight: FontWeight.w700,
                                color: AppColors.textMain,
                              ),
                            ),
                          ),
                          Text(
                            '${lines.length} รายการ',
                            style: const TextStyle(
                              fontFamily: AppStyles.fontFamily,
                              fontSize: 13,
                              color: AppColors.textSubtitle,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Divider(height: 1, color: AppColors.border),
                    Flexible(
                      child: ListView.separated(
                        shrinkWrap: true,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 12),
                        itemCount: lines.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 10),
                        itemBuilder: (context, index) {
                          final line = lines[index];
                          return Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: AppColors.surfaceAlt,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        line.part.partName,
                                        style: const TextStyle(
                                          fontFamily: AppStyles.fontFamily,
                                          fontSize: 14,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.textMain,
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        'รหัส ${line.part.partCode} • จำนวน ${line.quantity}',
                                        style: const TextStyle(
                                          fontFamily: AppStyles.fontFamily,
                                          fontSize: 12,
                                          color: AppColors.textSubtitle,
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      // 💰 [ใหม่] โชว์ราคารวมต่อรายการในตะกร้า
                                      Text(
                                        '${line.part.price.toStringAsFixed(0)} x ${line.quantity} = ${(line.part.price * line.quantity).toStringAsFixed(0)} บาท',
                                        style: const TextStyle(
                                          fontFamily: AppStyles.fontFamily,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                          color: AppColors.primary,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete_outline,
                                      color: AppColors.redText, size: 20),
                                  tooltip: 'นำออกจากตะกร้า',
                                  onPressed: () {
                                    setState(() => _cart.remove(line.part.cartKey));
                                    setSheetState(() {});
                                    if (_cart.isEmpty && sheetContext.mounted) {
                                      Navigator.pop(sheetContext);
                                    }
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    // 💰 [ใหม่] ยอดรวมราคาทั้งตะกร้า
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'ยอดรวม',
                            style: TextStyle(
                              fontFamily: AppStyles.fontFamily,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: AppColors.textMain,
                            ),
                          ),
                          Text(
                            '${lines.fold<double>(0, (sum, l) => sum + l.part.price * l.quantity).toStringAsFixed(0)} บาท',
                            style: const TextStyle(
                              fontFamily: AppStyles.fontFamily,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: AppColors.primary,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
                      child: SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          style: AppStyles.primaryButton.copyWith(
                            padding: const WidgetStatePropertyAll(
                              EdgeInsets.symmetric(vertical: 14),
                            ),
                          ),
                          onPressed: () {
                            Navigator.pop(sheetContext);
                            _submitCart();
                          },
                          icon: const Icon(Icons.check_circle_outline,
                              size: 18),
                          label: const Text(
                            'ยืนยันการเบิกอะไหล่ทั้งหมด',
                            style: TextStyle(
                              fontFamily: AppStyles.fontFamily,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ---------------------------------------------------------------------
  // ✅ ยืนยันคำขอเบิกทั้งหมดในตะกร้า — บันทึกลง DB ทีละรายการ + แจ้งเตือนแอดมิน
  // ---------------------------------------------------------------------
  Future<void> _submitCart() async {
    // 🐛 [แก้บัค] กันกดซ้ำ — ถ้ากำลังส่งคำขออยู่แล้ว (จากอีกปุ่มหนึ่ง หรือกดรัว)
    // ไม่ต้องทำซ้ำ ป้องกันคำขอเบิกซ้ำซ้อนของเดิมทุกชิ้นในตะกร้า
    if (_cart.isEmpty || _isSubmittingCart) return;

    final lines = _cart.values.toList();
    final technician = db.Session.currentUsername;

    setState(() => _isSubmittingCart = true);
    try {
      for (final line in lines) {
        await db.DatabaseHelper.instance.createPartRequest(
          technicianUsername: technician,
          // 🐛 [แก้บัค] เดิมส่ง line.part.id (ฟิลด์ id ภายในของอะไหล่ ซึ่งข้อมูล
          // เก่าบางส่วนมีค่าเป็น 0 ซ้ำกันหลายชิ้น) ทำให้ตอนแอดมินอนุมัติคำขอแล้ว
          // ระบบไปตัดสต๊อก/ค้นหาราคาผิดชิ้น (getSparePartById()/
          // updateSparePartStock() หาโหนดจาก part_id ตรงๆ ไม่เจอเพราะคีย์จริงใน
          // Firebase ไม่ใช่ 0) ส่งผลให้ราคาอะไหล่ไม่ขึ้นตอนออกบิลทั้งในแอปและเว็บ
          // ด้วย — เปลี่ยนมาส่ง cartKey (Firebase key จริงของแถวอะไหล่) แทน ซึ่ง
          // ไม่มีทางซ้ำกันได้ไม่ว่าฟิลด์ id ภายในจะถูกต้องหรือไม่
          partId: line.part.cartKey,
          partName: line.part.partName,
          partCode: line.part.partCode,
          quantity: line.quantity,
          repairId: widget.repairId,
        );
      }

      // 🔔 แจ้งเตือนแอดมินทุกคนว่ามีคำขอเบิกอะไหล่ใหม่
      final summary = lines
          .map((l) => '${l.part.partName} x${l.quantity}')
          .join(', ');
      final admins = await db.DatabaseHelper.instance.getAllAdmins();
      for (final admin in admins) {
        final adminUsername = admin['username']?.toString();
        if (adminUsername == null || adminUsername.isEmpty) continue;
        await db.DatabaseHelper.instance.createNotification({
          'user_username': adminUsername,
          'role': 'ADMIN',
          'title': 'มีคำขอเบิกอะไหล่ใหม่',
          'message': 'ช่าง $technician ขอเบิกอะไหล่: $summary',
          'type': 'PART_REQUEST',
          'is_read': 0,
        });
      }

      if (!mounted) return;
      setState(() => _cart.clear());
      _snack('ส่งคำขอเบิกอะไหล่เรียบร้อยแล้ว รอแอดมินดำเนินการ');
    } catch (e) {
      debugPrint('Error submitting part requests: $e');
      _snack('ส่งคำขอเบิกอะไหล่ไม่สำเร็จ: $e');
    } finally {
      // 🐛 [แก้บัค] ปลดธงกันกดซ้ำเสมอไม่ว่าจะสำเร็จหรือ error กันปุ่มค้างกดไม่ได้
      if (mounted) setState(() => _isSubmittingCart = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final parts = _filteredParts;

    return Scaffold(
      //backgroundColor: AppColors.redBg,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppHeader(
            // 🐛 [แก้บัค] เดิมเปลี่ยนหัวข้อเป็น "เบิกอะไหล่สำหรับงานนี้" ถ้าเปิด
            // มาจากหน้ารายละเอียดงาน (มี repairId) — ตามที่ขอให้ใช้คำว่า
            // "เบิกอะไหล่" เฉย ๆ เหมือนกันทุกกรณี
            title: 'เบิกอะไหล่',
            showBack: true,
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.refresh, color: Colors.white),
                  onPressed: _loadParts,
                ),
                // 🛒 ปุ่มตะกร้า พร้อมป้ายจำนวนชิ้นที่เลือกไว้
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.shopping_cart_outlined,
                          color: Colors.white),
                      onPressed: _openCart,
                    ),
                    if (_cartCount > 0)
                      Positioned(
                        right: 4,
                        top: 4,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 5, vertical: 1),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            '$_cartCount',
                            style: const TextStyle(
                              fontFamily: AppStyles.fontFamily,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: AppColors.primary,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          // ส่วนค้นหา
          Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'ค้นหาชื่อ / รหัสอะไหล่',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  onChanged: (v) => setState(() => _query = v),
                  decoration: InputDecoration(
                    hintText: 'เช่น Roller หรือ SP-001',
                    hintStyle: const TextStyle(color: AppColors.textHint),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: const BorderSide(color: Colors.grey),
                    ),
                    suffixIcon: const Icon(Icons.search),
                  ),
                ),
              ],
            ),
          ),

          // รายการอะไหล่
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : parts.isEmpty
                    ? const Center(
                        child: Text(
                          'ไม่พบรายการอะไหล่',
                          style: TextStyle(color: Colors.black54),
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _loadParts,
                        child: ListView.builder(
                          padding: const EdgeInsets.fromLTRB(24, 0, 24, 90),
                          itemCount: parts.length,
                          itemBuilder: (context, index) {
                            return _buildPartCard(parts[index]);
                          },
                        ),
                      ),
          ),
        ],
      ),

      // ✅ แถบล่างค้างจอ ให้กดยืนยันเบิกทั้งหมดได้ทันทีโดยไม่ต้องเปิดตะกร้าก่อน
      bottomNavigationBar: _cartCount == 0
          ? null
          : SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  border: Border(top: BorderSide(color: AppColors.border)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'เลือกไว้ $_cartCount ชิ้น (${_cart.length} รายการ)',
                        style: const TextStyle(
                          fontFamily: AppStyles.fontFamily,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textMain,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: _openCart,
                      child: const Text(
                        'ดูตะกร้า',
                        style: TextStyle(
                          fontFamily: AppStyles.fontFamily,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const SizedBox(width: 4),
                    ElevatedButton(
                      style: AppStyles.primaryButton,
                      // 🐛 [แก้บัค] ปิดปุ่มระหว่างกำลังส่งคำขออยู่ กันกดซ้ำ/กดรัว
                      // ตอนรอ Firebase บันทึกเสร็จ (ดูธง _isSubmittingCart)
                      onPressed: _isSubmittingCart ? null : _submitCart,
                      child: _isSubmittingCart
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Text(
                              'ยืนยันเบิก',
                              style: TextStyle(
                                fontFamily: AppStyles.fontFamily,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  // ==========================================
  // 3. การ์ดแสดงแต่ละรายการ — แสดงแค่ มี / หมด, แตะเพื่อดูรายละเอียด
  // ==========================================
  Widget _buildPartCard(PartItem part) {
    final inCart = _cart.containsKey(part.cartKey);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: () => _openPartDetail(part),
        child: Container(
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: inCart
                ? Border.all(color: AppColors.primary, width: 1.5)
                : null,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              // 🖼️ [แก้ไข] แสดงรูปจริงจาก photo_url ถ้ามี ไม่งั้นค่อย fallback เป็นไอคอน
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LocalOrNetworkImage(
                  path: part.photoUrl,
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                ),
              ),
              const SizedBox(width: 16),

              // ข้อมูลอะไหล่
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      part.partName,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'รหัส : ${part.partCode}',
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.black54,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 2),
                    // 💰 [ใหม่] โชว์ราคาต่อหน่วยให้ตรงกับหน้าเว็บ (เดิมโมเดลนี้
                    // ไม่มีฟิลด์ price เลย เลยไม่เคยแสดงราคาให้ช่างเห็น)
                    Text(
                      '${part.price.toStringAsFixed(0)} บาท / ชิ้น',
                      style: const TextStyle(
                        fontFamily: AppStyles.fontFamily,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.primary,
                      ),
                    ),
                    if (inCart) ...[
                      const SizedBox(height: 4),
                      Text(
                        'อยู่ในตะกร้า x${_cart[part.cartKey]!.quantity}',
                        style: const TextStyle(
                          fontFamily: AppStyles.fontFamily,
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: AppColors.primary,
                        ),
                      ),
                    ],
                  ],
                ),
              ),

              // 🟢🔴 สถานะ มี/หมด แบบ badge (ไม่โชว์จำนวนจริง)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: part.isAvailable
                      ? AppColors.greenBg
                      : AppColors.redBg,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: part.isAvailable ? Colors.green : Colors.red,
                  ),
                ),
                child: Text(
                  part.isAvailable ? 'มี' : 'หมด',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: part.isAvailable
                        ? AppColors.greenText
                        : AppColors.primary,
                  ),
                ),
              ),
              const SizedBox(width: 4),
              const Icon(Icons.chevron_right,
                  color: AppColors.textHint, size: 20),
            ],
          ),
        ),
      ),
    );
  }
}

/// ปุ่มบวก/ลบ ของตัวเลือกจำนวนใน popup รายละเอียดอะไหล่
class _StepperButton extends StatelessWidget {
  final IconData icon;
  final bool enabled;
  final VoidCallback onTap;

  const _StepperButton({
    required this.icon,
    required this.enabled,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: enabled ? AppColors.surfaceAlt : AppColors.surfaceAlt.withValues(alpha: 0.5),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: enabled ? onTap : null,
        child: SizedBox(
          width: 32,
          height: 32,
          child: Icon(
            icon,
            size: 16,
            color: enabled ? AppColors.textMain : AppColors.textHint,
          ),
        ),
      ),
    );
  }
}