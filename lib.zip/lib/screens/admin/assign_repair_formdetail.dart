// ==========================================
// SECTION 1: IMPORTS & ENUMS / HELPER
// ==========================================
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:after_sales/app_styles.dart';
import 'package:after_sales/screens/admin/admin_create_invoice.dart';
import 'package:after_sales/services.dart';
import 'package:after_sales/widgets.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:after_sales/screens/admin/admin_tracking.dart';
import 'package:after_sales/utils/firebase_number.dart';

/// 📌 Enum สำหรับจัดการสถานะงานซ่อม
enum RepairStatus {
  waiting('รอจัดสรรช่าง'),
  scheduledPending('รอดำเนินการ'),
  traveling('กำลังเดินทาง'),
  inProgress('กำลังซ่อม'),
  overdue('เกินกำหนดเวลา'),
  completed('เสร็จสิ้นแล้ว'),
  issue('มีปัญหา'), // 🔴 ปรับข้อความเป็น "มีปัญหา" ให้ตรงกับเว็บ
  cancelled('ยกเลิกแล้ว');

  final String label;
  const RepairStatus(this.label);

  static RepairStatus fromString(String? status) {
    if (status == null) return RepairStatus.waiting;
    final s = status.trim().toLowerCase();
    if (s == 'มีปัญหา' || s.contains('ปัญหา') || s == 'issue' || s == 'problem') {
      return RepairStatus.issue;
    }
    switch (s) {
      case 'กำลังเดินทาง':
        return RepairStatus.traveling;
      case 'กำลังดำเนินการ':
      case 'กำลังซ่อม':
      case 'inprogress':
      case 'in_progress':
        return RepairStatus.inProgress;
      case 'รอดำเนินการ':
        return RepairStatus.scheduledPending;
      case 'เกินกำหนดเวลา':
      case 'overdue':
        return RepairStatus.overdue;
      case 'เสร็จแล้ว':
      case 'เสร็จสิ้น':
      case 'เสร็จสิ้นแล้ว':
      case 'done':
      case 'completed':
        return RepairStatus.completed;
      case 'ยกเลิก':
      case 'cancelled':
      case 'canceled':
        return RepairStatus.cancelled;
      default:
        return RepairStatus.waiting;
    }
  }
}

class RepairStatusHelper {
  static Color getBgColor(RepairStatus status) {
    switch (status) {
      case RepairStatus.inProgress:
        return AppColors.blueBg;
      case RepairStatus.traveling:
        return const Color(0xFFDCEEFF);
      case RepairStatus.scheduledPending:
        return const Color(0xFFFFF7ED);
      case RepairStatus.overdue:
        return const Color(0xFFFFECEC);
      case RepairStatus.completed:
        return AppColors.greenBg;
      case RepairStatus.waiting:
        return AppColors.yellowBg;
      case RepairStatus.issue:
        return AppColors.redBg;
      case RepairStatus.cancelled:
        return AppColors.surfaceAlt;
    }
  }

  static Color getTextColor(RepairStatus status) {
    switch (status) {
      case RepairStatus.inProgress:
        return AppColors.blueText;
      case RepairStatus.traveling:
        return const Color(0xFF1D4ED8);
      case RepairStatus.scheduledPending:
        return const Color(0xFFEA580C);
      case RepairStatus.overdue:
        return const Color(0xFFB91C1C);
      case RepairStatus.completed:
        return AppColors.greenText;
      case RepairStatus.waiting:
        return AppColors.yellowText;
      case RepairStatus.issue:
        return AppColors.redText;
      case RepairStatus.cancelled:
        return AppColors.textSubtitle;
    }
  }
}

// ==========================================
// SECTION 2: DATA MODELS
// ==========================================

class TechnicianItem {
  final String username;
  final String name;
  final int jobsOnSelectedDate;

  const TechnicianItem({
    required this.username,
    required this.name,
    this.jobsOnSelectedDate = 0,
  });

  bool get isFull =>
      jobsOnSelectedDate >= DatabaseHelper.maxJobsPerTechnicianPerDay;

  TechnicianItem copyWith({int? jobsOnSelectedDate}) => TechnicianItem(
        username: username,
        name: name,
        jobsOnSelectedDate: jobsOnSelectedDate ?? this.jobsOnSelectedDate,
      );
}

class AppointmentDate {
  AppointmentDate._();

  static const List<String> _monthsTh = [
    'ม.ค.', 'ก.พ.', 'มี.ค.', 'เม.ย.', 'พ.ค.', 'มิ.ย.',
    'ก.ค.', 'ส.ค.', 'ก.ย.', 'ต.ค.', 'พ.ย.', 'ธ.ค.',
  ];

  static String toDbText(DateTime d) => '${d.day}/${d.month}/${d.year + 543}';

  static String toDisplay(DateTime d) =>
      '${d.day} ${_monthsTh[d.month - 1]} ${d.year + 543}';

  static DateTime? parse(String? text) {
    if (text == null || text.trim().isEmpty || text.trim() == '-') return null;
    final parts = text.trim().split('/');
    if (parts.length != 3) return null;
    final day = int.tryParse(parts[0]);
    final month = int.tryParse(parts[1]);
    var year = int.tryParse(parts[2]);
    if (day == null || month == null || year == null) return null;
    if (year > 2400) year -= 543;
    if (month < 1 || month > 12) return null;
    try {
      return DateTime(year, month, day);
    } catch (_) {
      return null;
    }
  }
}

class AdminJobInfo {
  final String ticketId;
  final String machineCode;
  final String modelName;
  final String description;
  final RepairStatus status;
  final String customerName;
  final String customerPhone;
  final String address;
  final double? destLat;
  final double? destLng;
  final String appointmentDate;
  final String appointmentTime;
  final List<String> images;
  final String reportFormCode;
  final String reportProblemDetail;
  final String reportBeforePhoto;
  final String reportAfterPhoto;
  final String reportSlipPhoto;
  final String? reportSubmittedAt;
  // 🔴 ข้อมูลปัญหาที่ช่างแจ้ง
  final String problemNote;
  final List<String> problemPhotos;
  final String? problemReportedBy;
  final String? problemReportedAt;
  // 🆕 [ใหม่] ใช้เช็คเงื่อนไขออกบิล (ดู _canIssueInvoice) — ราคาที่ช่างบันทึก
  // ระหว่างซ่อม (estimated_price) และยอดที่ตั้งไปแล้วถ้าเคยออกบิล (total_price)
  final double estimatedPrice;
  final double totalPrice;

  const AdminJobInfo({
    required this.ticketId,
    required this.machineCode,
    required this.modelName,
    required this.description,
    required this.status,
    required this.customerName,
    required this.customerPhone,
    required this.address,
    this.destLat,
    this.destLng,
    required this.appointmentDate,
    this.appointmentTime = '',
    this.images = const [],
    this.reportFormCode = '',
    this.reportProblemDetail = '',
    this.reportBeforePhoto = '',
    this.reportAfterPhoto = '',
    this.reportSlipPhoto = '',
    this.reportSubmittedAt,
    this.problemNote = '',
    this.problemPhotos = const [],
    this.problemReportedBy,
    this.problemReportedAt,
    this.estimatedPrice = 0,
    this.totalPrice = 0,
  });

  bool get hasReport =>
      reportSubmittedAt != null && reportSubmittedAt!.isNotEmpty;

  bool get hasProblem =>
      status == RepairStatus.issue ||
      problemNote.isNotEmpty ||
      problemPhotos.isNotEmpty;
}

// ==========================================
// SECTION 3: MAIN WIDGET
// ==========================================

class AssignRepairFormDetailPage extends StatefulWidget {
  final int repairId;

  const AssignRepairFormDetailPage({super.key, required this.repairId});

  @override
  State<AssignRepairFormDetailPage> createState() =>
      _AssignRepairFormDetailPageState();
}

class _AssignRepairFormDetailPageState
    extends State<AssignRepairFormDetailPage> {
  AdminJobInfo? _job;
  List<TechnicianItem> _technicians = [];
  // 🆕 [ใหม่] คำขอเบิกอะไหล่ทุกสถานะของงานนี้ — ใช้เช็คว่ายังมีรายการค้าง
  // "รอดำเนินการ" (แอดมินยังไม่อนุมัติ/ปฏิเสธ) อยู่ไหม ก่อนอนุญาตออกบิล
  List<Map<String, dynamic>> _partRequests = [];

  String? _selectedTechnicianUsername;
  String? _assignedTechnicianUsername;
  String? _assignedTechnicianName;

  DateTime? _appointmentDate;
  TimeOfDay? _appointmentTime;

  bool _isLoading = true;
  bool _isAssigning = false;
  bool _isCheckingQuota = false;
  bool _isResolvingProblem = false;

  // 🆕 [ใหม่] เงื่อนไขออกบิล — ให้ตรงกับ isInvoiceable() ฝั่งเว็บ (JobDetailModal
  // / FinancePage.jsx) ทุกจุด: ต้องยังไม่เคยออกบิล (total_price ยังไม่ตั้ง),
  // ไม่ใช่งานที่ยกเลิกแล้ว, ช่างบันทึกราคาประเมินไว้แล้ว (estimated_price > 0),
  // และคำขอเบิกอะไหล่ของงานนี้ต้องไม่มีรายการที่ยัง "รอดำเนินการ" ค้างอยู่ (ต้อง
  // อนุมัติ/ปฏิเสธให้ครบก่อน) — เดิมเงื่อนไขนี้ไม่มีเลยฝั่งแอป ปุ่ม "ออกบิล" เลย
  // โชว์ตลอดไม่ว่างานจะพร้อมออกบิลจริงหรือไม่
  bool get _hasPendingPartRequests =>
      _partRequests.any((r) => r['status']?.toString() == 'รอดำเนินการ');

  bool get _canIssueInvoice {
    final job = _job;
    if (job == null) return false;
    if (job.status == RepairStatus.cancelled) return false;
    if (job.totalPrice > 0) return false;
    if (job.estimatedPrice <= 0) return false;
    if (_hasPendingPartRequests) return false;
    return true;
  }

  @override
  void initState() {
    super.initState();
    _loadDataFromDatabase();
  }

  String _formatTimeOfDay(TimeOfDay? time) {
    if (time == null) return 'แตะเพื่อเลือกเวลา';
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute น.';
  }

  Future<void> _loadDataFromDatabase() async {
    setState(() => _isLoading = true);

    try {
      final dbHelper = DatabaseHelper.instance;

      final repairRow = await dbHelper.getRepairById(widget.repairId);
      final techList = await dbHelper.getAllTechnicians();
      _technicians = techList
          .map((item) {
            return TechnicianItem(
              username: item['username']?.toString() ?? '',
              name: item['tech_name']?.toString() ??
                  item['name']?.toString() ??
                  'ไม่ระบุชื่อ',
            );
          })
          .where((t) => t.username.isNotEmpty)
          .toList();

      if (repairRow != null) {
        final rawImages = repairRow['images']?.toString() ?? '';
        final imageList = rawImages.isNotEmpty
            ? rawImages
                .split(',')
                .map((e) => e.trim())
                .where((e) => e.isNotEmpty)
                .toList()
            : <String>[];

        String cusName = '-';
        String cusPhone = '-';
        final cusUsername = repairRow['customer_username']?.toString();

        if (cusUsername != null && cusUsername.isNotEmpty) {
          final customer = await dbHelper.getCustomerProfile(cusUsername);
          if (customer != null) {
            cusName =
                '${customer['name'] ?? ''} ${customer['surname'] ?? ''}'.trim();
            if (cusName.isEmpty) cusName = cusUsername;
            cusPhone = customer['phone']?.toString() ?? '-';
          }
        }

        final statusStr = repairRow['status']?.toString();

        String timeStr = (repairRow['appointment_time']?.toString() ?? '').trim();
        if (timeStr.isEmpty) {
          timeStr = (repairRow['time']?.toString() ?? '').trim();
        }
        if (timeStr.isEmpty) {
          timeStr = (repairRow['appointmentTime']?.toString() ?? '').trim();
        }

        final cleanTime = timeStr.replaceAll('น.', '').trim();
        if (cleanTime.contains(':')) {
          final parts = cleanTime.split(':');
          if (parts.length >= 2) {
            final h = int.tryParse(parts[0].replaceAll(RegExp(r'[^0-9]'), ''));
            final m = int.tryParse(parts[1].replaceAll(RegExp(r'[^0-9]'), ''));
            if (h != null && m != null) {
              _appointmentTime = TimeOfDay(hour: h, minute: m);
            }
          }
        }
        _appointmentTime ??= const TimeOfDay(hour: 9, minute: 0);

        // 🔴 ดึงข้อมูลปัญหาที่ช่างแจ้ง
        final probNote = repairRow['problem_note']?.toString() ?? '';
        final rawProbPhotos = repairRow['problem_photos']?.toString() ?? '';
        final probPhotos = rawProbPhotos.isNotEmpty
            ? rawProbPhotos
                .split(',')
                .map((e) => e.trim())
                .where((e) => e.isNotEmpty)
                .toList()
            : <String>[];
        final probBy = repairRow['problem_reported_by']?.toString();
        final probAt = repairRow['problem_reported_at']?.toString();

        _job = AdminJobInfo(
          ticketId: repairRow['ticketNo']?.toString() ??
              repairRow['ticket_no']?.toString() ??
              '#AS-${repairRow['id']}',
          machineCode: repairRow['machine']?.toString() ??
              repairRow['machine_code']?.toString() ??
              '-',
          modelName: repairRow['model_name']?.toString() ?? '-',
          description: repairRow['detail']?.toString() ?? '-',
          status: RepairStatus.fromString(statusStr),
          customerName: cusName,
          customerPhone: cusPhone,
          address: repairRow['location']?.toString() ??
              repairRow['address']?.toString() ??
              '-',
          destLat: toDoubleOrNull(repairRow['dest_lat']),
          destLng: toDoubleOrNull(repairRow['dest_lng']),
          appointmentDate: repairRow['date']?.toString() ?? '-',
          appointmentTime: cleanTime.isNotEmpty ? cleanTime : timeStr,
          images: imageList,
          reportFormCode: repairRow['report_form_code']?.toString() ?? '',
          reportProblemDetail:
              repairRow['report_problem_detail']?.toString() ?? '',
          reportBeforePhoto:
              repairRow['report_before_photo']?.toString() ?? '',
          reportAfterPhoto: repairRow['report_after_photo']?.toString() ?? '',
          reportSlipPhoto: repairRow['report_slip_photo']?.toString() ?? '',
          reportSubmittedAt: repairRow['report_submitted_at']?.toString(),
          problemNote: probNote,
          problemPhotos: probPhotos,
          problemReportedBy: probBy,
          problemReportedAt: probAt,
          estimatedPrice: toDoubleOrNull(repairRow['estimated_price']) ?? 0,
          totalPrice: toDoubleOrNull(repairRow['total_price']) ?? 0,
        );

        _assignedTechnicianUsername =
            repairRow['technician_username']?.toString();

        if (_assignedTechnicianUsername != null) {
          final match = _technicians
              .where((t) => t.username == _assignedTechnicianUsername);
          if (match.isNotEmpty) {
            _assignedTechnicianName = match.first.name;
          }
        }

        _selectedTechnicianUsername = _assignedTechnicianUsername;
        _appointmentDate =
            AppointmentDate.parse(_job?.appointmentDate) ?? DateTime.now();

        // 🆕 [ใหม่] โหลดคำขอเบิกอะไหล่ทุกสถานะของงานนี้ ให้ _canIssueInvoice
        // เช็คได้ว่ายังมีรายการค้าง "รอดำเนินการ" อยู่ไหม
        _partRequests =
            await dbHelper.getPartRequestsForRepair(widget.repairId);
      }

      await _refreshTechnicianWorkload();
    } catch (e) {
      debugPrint('Error loading data: $e');
      _showSnackBar('เกิดข้อผิดพลาดในการโหลดข้อมูล');
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _refreshTechnicianWorkload() async {
    final date = _appointmentDate;
    if (date == null || _technicians.isEmpty) return;

    try {
      final counts = await DatabaseHelper.instance
          .getTechnicianJobCountsForDate(
        AppointmentDate.toDbText(date),
        excludeRepairId: widget.repairId,
      );

      _technicians = _technicians
          .map((t) => t.copyWith(jobsOnSelectedDate: counts[t.username] ?? 0))
          .toList();

      final selected = _selectedTechnicianUsername;
      if (selected != null) {
        final match = _technicians.where((t) => t.username == selected);
        if (match.isNotEmpty && match.first.isFull) {
          _selectedTechnicianUsername = null;
        }
      }
    } catch (e) {
      debugPrint('Error loading technician workload: $e');
    }
  }

  Future<bool> _pickAppointmentDate() async {
    final now = DateTime.now();
    final firstDate = DateTime(now.year, now.month, now.day);
    final initial = _appointmentDate ?? firstDate;

    final picked = await showDatePicker(
      context: context,
      initialDate: initial.isBefore(firstDate) ? firstDate : initial,
      firstDate: firstDate,
      lastDate: DateTime(now.year + 2, 12, 31),
      helpText: 'เลือกวันนัดซ่อม',
      cancelText: 'ยกเลิก',
      confirmText: 'เลือกวันนี้',
      fieldLabelText: 'วันนัดซ่อม',
    );

    if (picked == null || !mounted) return false;

    setState(() {
      _appointmentDate = picked;
      _isCheckingQuota = true;
    });

    await _refreshTechnicianWorkload();

    if (!mounted) return false;
    setState(() => _isCheckingQuota = false);
    return true;
  }

  Future<void> _pickAppointmentTime() async {
    final initial = _appointmentTime ?? const TimeOfDay(hour: 9, minute: 0);
    final now = DateTime.now();
    DateTime tempPicked = DateTime(
      now.year,
      now.month,
      now.day,
      initial.hour,
      initial.minute,
    );

    bool useKeyboardInput = false;
    final hourController = TextEditingController(
      text: initial.hour.toString().padLeft(2, '0'),
    );
    final minuteController = TextEditingController(
      text: initial.minute.toString().padLeft(2, '0'),
    );

    int clamp(int value, int min, int max) =>
        value < min ? min : (value > max ? max : value);

    final picked = await showModalBottomSheet<TimeOfDay>(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheetState) {
            void syncTempFromFields() {
              final h = clamp(int.tryParse(hourController.text) ?? 0, 0, 23);
              final m = clamp(
                int.tryParse(minuteController.text) ?? 0,
                0,
                59,
              );
              tempPicked = DateTime(now.year, now.month, now.day, h, m);
            }

            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(sheetContext).viewInsets.bottom,
              ),
              child: SafeArea(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          TextButton(
                            onPressed: () => Navigator.pop(sheetContext),
                            child: const Text(
                              'ยกเลิก',
                              style: TextStyle(color: AppColors.textSubtitle),
                            ),
                          ),
                          Row(
                            children: [
                              const Text(
                                'เลือกเวลานัดหมาย',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textHeading,
                                ),
                              ),
                              IconButton(
                                tooltip: useKeyboardInput
                                    ? 'สลับเป็นเลื่อนเวลา'
                                    : 'สลับเป็นพิมพ์เวลา',
                                icon: Icon(
                                  useKeyboardInput
                                      ? Icons.schedule
                                      : Icons.keyboard,
                                  color: AppColors.primary,
                                  size: 20,
                                ),
                                onPressed: () {
                                  if (!useKeyboardInput) {
                                    // switching TO keyboard: seed fields from wheel
                                    hourController.text = tempPicked.hour
                                        .toString()
                                        .padLeft(2, '0');
                                    minuteController.text = tempPicked.minute
                                        .toString()
                                        .padLeft(2, '0');
                                  } else {
                                    // switching TO wheel: seed wheel from fields
                                    syncTempFromFields();
                                  }
                                  setSheetState(
                                    () =>
                                        useKeyboardInput = !useKeyboardInput,
                                  );
                                },
                              ),
                            ],
                          ),
                          TextButton(
                            onPressed: () {
                              if (useKeyboardInput) {
                                syncTempFromFields();
                              }
                              Navigator.pop(
                                sheetContext,
                                TimeOfDay(
                                  hour: tempPicked.hour,
                                  minute: tempPicked.minute,
                                ),
                              );
                            },
                            child: const Text(
                              'ตกลง',
                              style: TextStyle(
                                color: AppColors.primary,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Divider(height: 1),
                    if (useKeyboardInput)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 32),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 70,
                              child: TextField(
                                controller: hourController,
                                autofocus: true,
                                keyboardType: TextInputType.number,
                                maxLength: 2,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textHeading,
                                ),
                                decoration: const InputDecoration(
                                  counterText: '',
                                  hintText: 'ชม.',
                                  border: OutlineInputBorder(),
                                ),
                                onChanged: (_) => syncTempFromFields(),
                              ),
                            ),
                            const Padding(
                              padding: EdgeInsets.symmetric(horizontal: 8),
                              child: Text(
                                ':',
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 70,
                              child: TextField(
                                controller: minuteController,
                                keyboardType: TextInputType.number,
                                maxLength: 2,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textHeading,
                                ),
                                decoration: const InputDecoration(
                                  counterText: '',
                                  hintText: 'นาที',
                                  border: OutlineInputBorder(),
                                ),
                                onChanged: (_) => syncTempFromFields(),
                              ),
                            ),
                          ],
                        ),
                      )
                    else
                      SizedBox(
                        height: 220,
                        child: CupertinoTheme(
                          data: const CupertinoThemeData(
                            textTheme: CupertinoTextThemeData(
                              dateTimePickerTextStyle: TextStyle(
                                fontSize: 20,
                                color: AppColors.textHeading,
                              ),
                            ),
                          ),
                          child: CupertinoDatePicker(
                            mode: CupertinoDatePickerMode.time,
                            initialDateTime: tempPicked,
                            use24hFormat: true,
                            minuteInterval: 1,
                            onDateTimeChanged: (value) => tempPicked = value,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    hourController.dispose();
    minuteController.dispose();

    if (picked != null && mounted) {
      setState(() => _appointmentTime = picked);
    }
  }

  void _onTechnicianTap(TechnicianItem tech) {
    if (tech.isFull) {
      _showSnackBar(
        'วันที่เลือก ${tech.name} มีงานครบ '
        '${DatabaseHelper.maxJobsPerTechnicianPerDay} งานแล้ว '
        'กรุณาเลือกช่างคนอื่นหรือเปลี่ยนวันนัดซ่อม',
      );
      return;
    }
    setState(() => _selectedTechnicianUsername = tech.username);
  }

  Future<void> _handleAssign() async {
    if (_selectedTechnicianUsername == null) {
      _showSnackBar('กรุณาเลือกช่างก่อนกดมอบหมาย');
      return;
    }

    final currentAdmin = Session.currentUsername;
    if (currentAdmin.isEmpty) {
      _showSnackBar('เซสชันหมดอายุ กรุณาล็อกอินใหม่อีกครั้ง');
      return;
    }

    if (_appointmentDate == null) {
      _showSnackBar('กรุณาเลือกวันนัดซ่อมก่อนมอบหมายงาน');
      return;
    }

    final latestCounts = await DatabaseHelper.instance
        .getTechnicianJobCountsForDate(
      AppointmentDate.toDbText(_appointmentDate!),
      excludeRepairId: widget.repairId,
    );
    final currentLoad = latestCounts[_selectedTechnicianUsername!] ?? 0;
    if (currentLoad >= DatabaseHelper.maxJobsPerTechnicianPerDay) {
      _showSnackBar(
        'ช่างคนนี้มีงานครบ ${DatabaseHelper.maxJobsPerTechnicianPerDay} '
        'งานในวันที่เลือกแล้ว กรุณาเลือกใหม่',
      );
      await _refreshTechnicianWorkload();
      if (mounted) setState(() {});
      return;
    }

    setState(() => _isAssigning = true);

    try {
      final dbHelper = DatabaseHelper.instance;
      final formattedTime = _appointmentTime != null
          ? '${_appointmentTime!.hour.toString().padLeft(2, '0')}:${_appointmentTime!.minute.toString().padLeft(2, '0')}'
          : '09:00';

      await dbHelper.assignTechnicianToRepair(
        repairId: widget.repairId,
        techUsername: _selectedTechnicianUsername!,
        adminUsername: currentAdmin,
        appointmentDate: AppointmentDate.toDbText(_appointmentDate!),
      );

      final adminProfile = await dbHelper.getAdminProfile(currentAdmin);
      await dbHelper.updateRepair(widget.repairId, {
        if (adminProfile != null) ...{
          'admin_name': adminProfile['admin_name'],
          'admin_code': adminProfile['admin_code'],
        },
        'time': formattedTime,
        'appointment_time': formattedTime,
      });

      if (_job != null) {
        await dbHelper.createNotification({
          'user_username': _selectedTechnicianUsername!,
          'role': 'TECHNICIAN',
          'title': 'ได้รับมอบหมายงานใหม่',
          'message':
              'คุณได้รับมอบหมายงานซ่อม ${_job!.ticketId} (${_job!.machineCode}) '
              'นัดซ่อมวันที่ ${AppointmentDate.toDisplay(_appointmentDate!)} เวลา $formattedTime น.',
          'type': 'REPAIR_ASSIGNED',
          'target_id': widget.repairId,
          'is_read': 0,
        });
      }

      if (!mounted) return;
      Navigator.pop(context, true);
    } catch (e) {
      debugPrint('Error assigning technician: $e');
      if (mounted) {
        setState(() => _isAssigning = false);
        _showSnackBar('เกิดข้อผิดพลาดในการบันทึกข้อมูล');
      }
    }
  }

  // 🔴 ฟังก์ชันปลดสถานะมีปัญหากลับเป็นสถานะเดิม (Resolve Issue)
  Future<void> _resolveProblem() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ยืนยันแก้ไขปัญหาแล้ว?'),
        content: const Text(
            'ต้องการเปลี่ยนสถานะงานนี้กลับเป็นสถานะปกติเพื่อให้ดำเนินการต่อใช่หรือไม่?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('ยกเลิก'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
            ),
            child: const Text('ยืนยัน'),
          ),
        ],
      ),
    );

    if (confirm != true || !mounted) return;

    setState(() => _isResolvingProblem = true);

    try {
      await DatabaseHelper.instance.resolveRepairProblem(widget.repairId);
      _showSnackBar('แก้ไขปัญหาและคืนสถานะงานเรียบร้อยแล้ว');
      await _loadDataFromDatabase();
    } catch (e) {
      debugPrint('Error resolving problem: $e');
      _showSnackBar('เกิดข้อผิดพลาดในการคืนสถานะงาน: $e');
    } finally {
      if (mounted) setState(() => _isResolvingProblem = false);
    }
  }

  void _openTrackingMap() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AdminTrackingPage(repairId: widget.repairId),
      ),
    );
  }

  Future<void> _makePhoneCall(String phoneNumber) async {
    if (phoneNumber.isEmpty || phoneNumber == '-') {
      _showSnackBar('ไม่พบเบอร์โทรศัพท์ลูกค้า');
      return;
    }

    final Uri phoneUri =
        Uri(scheme: 'tel', path: phoneNumber.replaceAll(RegExp(r'\s+'), ''));

    try {
      if (await canLaunchUrl(phoneUri)) {
        await launchUrl(phoneUri);
      } else {
        _showSnackBar('ไม่สามารถเปิดแอปโทรศัพท์ได้');
      }
    } catch (e) {
      _showSnackBar('เกิดข้อผิดพลาดในการกดโทรออก');
    }
  }

  void _showImagePreview(BuildContext context, String path) {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.black.withValues(alpha: 0.9),
        insetPadding: EdgeInsets.zero,
        child: Stack(
          alignment: Alignment.center,
          children: [
            InteractiveViewer(
              minScale: 0.5,
              maxScale: 4.0,
              child: path.startsWith('http')
                  ? Image.network(
                      path,
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) => const Icon(
                          Icons.broken_image,
                          color: Colors.white,
                          size: 80),
                    )
                  : Image.file(
                      File(path),
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) => const Icon(
                          Icons.broken_image,
                          color: Colors.white,
                          size: 80),
                    ),
            ),
            Positioned(
              top: 40,
              right: 20,
              child: IconButton(
                icon: const Icon(Icons.close, color: Colors.white, size: 30),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSnackBar(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message,
            style: const TextStyle(fontFamily: AppStyles.fontFamily)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        top: false,
        bottom: false,
        child: Column(
          children: [
            AppHeader(
              title: 'ใบแจ้งซ่อม #${widget.repairId}',
              showBack: true,
            ),
            Expanded(
              child: _isLoading
                  ? const Center(
                      child:
                          CircularProgressIndicator(color: AppColors.primary))
                  : _job == null
                      ? const Center(
                          child: Text('ไม่พบข้อมูลใบแจ้งซ่อม',
                              style:
                                  TextStyle(fontFamily: AppStyles.fontFamily)))
                      : ListView(
                          padding: const EdgeInsets.all(20),
                          children: [
                            _JobInfoCard(
                              job: _job!,
                              // 🔒 งานเสร็จสิ้นแล้ว = ช่างเลิกแชร์ตำแหน่งแล้ว
                              // เปิดแผนที่ต่อจะเจอ Firebase permission denied
                              // จึงปิดปุ่มไปเลยแทนที่จะให้กดแล้วเจอ error
                              onMap: _job!.status == RepairStatus.completed
                                  ? null
                                  : _openTrackingMap,
                              onCall: () =>
                                  _makePhoneCall(_job!.customerPhone),
                              onImageTap: (path) =>
                                  _showImagePreview(context, path),
                            ),
                            // 🔴 ส่วนแสดงการ์ดปัญหาที่พบ (ถ้ามี)
                            if (_job!.hasProblem) ...[
                              const SizedBox(height: 20),
                              _ProblemReportCard(
                                job: _job!,
                                isResolving: _isResolvingProblem,
                                onImageTap: (path) =>
                                    _showImagePreview(context, path),
                                onResolve: _resolveProblem,
                              ),
                            ],
                            if (_job!.hasReport) ...[
                              const SizedBox(height: 20),
                              _RepairReportCard(
                                job: _job!,
                                onImageTap: (path) =>
                                    _showImagePreview(context, path),
                              ),
                            ],
                            if (_job!.status != RepairStatus.completed) ...[
                              const SizedBox(height: 20),
                              _AssignCard(
                                technicians: _technicians,
                                selectedTechnicianUsername:
                                    _selectedTechnicianUsername,
                                assignedTechnicianName:
                                    _assignedTechnicianName,
                                appointmentDate: _appointmentDate,
                                appointmentTime: _appointmentTime,
                                formattedTime: _formatTimeOfDay(_appointmentTime),
                                isAssigning: _isAssigning,
                                isCheckingQuota: _isCheckingQuota,
                                onTechnicianTap: _onTechnicianTap,
                                onPickDate: _pickAppointmentDate,
                                onPickTime: _pickAppointmentTime,
                                onAssign: _handleAssign,
                              ),
                            ],
                            if (_canIssueInvoice) ...[
                              const SizedBox(height: 20),
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton.icon(
                                  style: AppStyles.primaryButton,
                                  onPressed: () async {
                                    final saved = await Navigator.push<bool>(
                                      context,
                                      MaterialPageRoute(
                                        builder: (_) => AdminCreateInvoicePage(
                                          initialRepairId:
                                              widget.repairId.toString(),
                                          initialTicketId: _job!.ticketId,
                                          initialCustomerName:
                                              _job!.customerName,
                                          initialCustomerPhone:
                                              _job!.customerPhone,
                                          initialAddress: _job!.address,
                                        ),
                                      ),
                                    );
                                    if (saved == true) _loadDataFromDatabase();
                                  },
                                  icon: const Icon(Icons.receipt_long),
                                  label: const Text('ออกบิล'),
                                ),
                              ),
                            ],
                          ],
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// SECTION 7: SUB-WIDGETS
// ==========================================

class _SectionCard extends StatelessWidget {
  final Widget child;
  const _SectionCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 6,
            offset: Offset(0, 2),
          )
        ],
      ),
      child: child,
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(
            color: AppColors.textMain,
            fontSize: 14,
            fontFamily: AppStyles.fontFamily,
          ),
          children: [
            TextSpan(
              text: '$label : ',
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            TextSpan(
              text: value,
              style: const TextStyle(fontWeight: FontWeight.w400),
            ),
          ],
        ),
      ),
    );
  }
}

class _JobInfoCard extends StatelessWidget {
  final AdminJobInfo job;
  final VoidCallback? onMap;
  final VoidCallback onCall;
  final ValueChanged<String> onImageTap;

  const _JobInfoCard({
    required this.job,
    required this.onMap,
    required this.onCall,
    required this.onImageTap,
  });

  @override
  Widget build(BuildContext context) {
    final formattedTimeText = job.appointmentTime.trim().isNotEmpty
        ? (job.appointmentTime.contains('น.')
            ? job.appointmentTime.trim()
            : '${job.appointmentTime.trim()} น.')
        : '';
    final displayDate = formattedTimeText.isNotEmpty
        ? '${job.appointmentDate} ($formattedTimeText)'
        : job.appointmentDate;

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'รายละเอียดงาน',
            textAlign: TextAlign.center,
            style: AppStyles.title.copyWith(
              color: AppColors.primary,
              fontSize: 20,
              fontFamily: AppStyles.fontFamily,
            ),
          ),
          const SizedBox(height: 16),
          _InfoRow(label: 'เลขแจ้งซ่อม', value: job.ticketId),
          _InfoRow(label: 'เครื่อง / รหัส', value: job.machineCode),
          _InfoRow(label: 'อาการ / รายละเอียด', value: job.description),
          const SizedBox(height: 6),

          Row(
            children: [
              const Text(
                'สถานะ : ',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  fontFamily: AppStyles.fontFamily,
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: RepairStatusHelper.getBgColor(job.status),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.circle,
                      size: 7,
                      color: RepairStatusHelper.getTextColor(job.status),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      job.status.label,
                      style: TextStyle(
                        color: RepairStatusHelper.getTextColor(job.status),
                        fontSize: 12,
                        fontFamily: AppStyles.fontFamily,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _InfoRow(label: 'ชื่อลูกค้า', value: job.customerName),

          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(
              children: [
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      style: const TextStyle(
                        color: AppColors.textMain,
                        fontSize: 14,
                        fontFamily: AppStyles.fontFamily,
                      ),
                      children: [
                        const TextSpan(
                          text: 'เบอร์ : ',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        TextSpan(
                          text: job.customerPhone,
                          style: const TextStyle(fontWeight: FontWeight.w400),
                        ),
                      ],
                    ),
                  ),
                ),
                if (job.customerPhone != '-')
                  InkWell(
                    onTap: onCall,
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.phone,
                        color: Colors.green,
                        size: 18,
                      ),
                    ),
                  ),
              ],
            ),
          ),

          _InfoRow(label: 'ที่อยู่', value: job.address),
          _InfoRow(label: 'วัน-เวลานัดซ่อม', value: displayDate),
          // 🆕 [ใหม่] โชว์วันที่งานเสร็จสิ้นจริงในการ์ดข้อมูลงานด้วย (เดิมมีแค่
          // "ส่งรายงานเมื่อ" ในการ์ดรายงานจากช่างด้านล่างของหน้าเดียวกัน ซึ่งอยู่
          // ไกลจากข้อมูลงานหลัก) — เส้นทางเดียวกับหน้าลูกค้า/ช่าง/ลิสต์แอดมิน
          if (job.status == RepairStatus.completed && job.reportSubmittedAt != null)
            _InfoRow(
              label: 'วันที่เสร็จสิ้น',
              value: formatNotificationDateTime(job.reportSubmittedAt),
            ),
          const SizedBox(height: 14),
          const Text(
            'รูปภาพประกอบ (แตะเพื่อขยาย)',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 14,
              fontFamily: AppStyles.fontFamily,
            ),
          ),
          const SizedBox(height: 8),

          job.images.isEmpty
              ? Container(
                  height: 80,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text(
                    'ไม่มีรูปภาพแนบมา',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 13,
                      fontFamily: AppStyles.fontFamily,
                    ),
                  ),
                )
              : SizedBox(
                  height: 100,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: job.images.length,
                    separatorBuilder: (context, index) =>
                        const SizedBox(width: 10),
                    itemBuilder: (context, index) => GestureDetector(
                      onTap: () => onImageTap(job.images[index]),
                      child: _photo(job.images[index]),
                    ),
                  ),
                ),

          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: onMap,
              style: AppStyles.primaryButton.copyWith(
                padding: const WidgetStatePropertyAll(
                  EdgeInsets.symmetric(vertical: 12),
                ),
              ),
              icon: const Icon(Icons.near_me_outlined, size: 18),
              label: const Text('ดูตำแหน่ง/เส้นทางในแอป',
                  style: TextStyle(fontFamily: AppStyles.fontFamily)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _photo(String path) {
    Widget imageWidget;

    if (path.startsWith('http')) {
      imageWidget = Image.network(
        path,
        width: 80,
        height: 100,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => _imagePlaceholder(),
      );
    } else {
      imageWidget = Image.file(
        File(path),
        width: 80,
        height: 100,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) => _imagePlaceholder(),
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(8),
      child: imageWidget,
    );
  }

  Widget _imagePlaceholder() {
    return Container(
      width: 80,
      height: 100,
      color: Colors.grey.shade200,
      child: const Icon(Icons.broken_image, color: Colors.grey),
    );
  }
}

// 🔴 การ์ดแสดงปัญหาที่ช่างแจ้งเข้ามา พร้อมปุ่มคืนสถานะงาน
class _ProblemReportCard extends StatelessWidget {
  final AdminJobInfo job;
  final bool isResolving;
  final ValueChanged<String> onImageTap;
  final VoidCallback onResolve;

  const _ProblemReportCard({
    required this.job,
    required this.isResolving,
    required this.onImageTap,
    required this.onResolve,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFDE68A)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x14000000),
            blurRadius: 6,
            offset: Offset(0, 2),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: const BoxDecoration(
                  color: Color(0xFFFEF3C7),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    size: 20, color: Color(0xFFD97706)),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'ปัญหาที่พบระหว่างปฏิบัติงาน',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    fontFamily: AppStyles.fontFamily,
                    color: Color(0xFF92400E),
                  ),
                ),
              ),
            ],
          ),
          if (job.problemReportedAt != null) ...[
            const SizedBox(height: 4),
            Text(
              'แจ้งปัญหาเมื่อ ${formatNotificationDateTime(job.problemReportedAt)}'
              '${job.problemReportedBy != null ? ' โดย ${job.problemReportedBy}' : ''}',
              style: const TextStyle(
                fontSize: 12,
                color: Color(0xFFB45309),
                fontFamily: AppStyles.fontFamily,
              ),
            ),
          ],
          const SizedBox(height: 12),
          Text(
            job.problemNote.isNotEmpty
                ? job.problemNote
                : 'ช่างแจ้งว่ามีปัญหาหน้างาน แต่ยังไม่ได้ระบุรายละเอียดเพิ่มเติม',
            style: const TextStyle(
              fontSize: 14,
              fontFamily: AppStyles.fontFamily,
              color: AppColors.textMain,
              height: 1.4,
            ),
          ),
          if (job.problemPhotos.isNotEmpty) ...[
            const SizedBox(height: 12),
            SizedBox(
              height: 90,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: job.problemPhotos.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (context, index) {
                  final photoUrl = job.problemPhotos[index];
                  return GestureDetector(
                    onTap: () => onImageTap(photoUrl),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        photoUrl,
                        width: 80,
                        height: 90,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(
                          width: 80,
                          height: 90,
                          color: Colors.grey.shade200,
                          child: const Icon(Icons.broken_image,
                              color: Colors.grey),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: isResolving ? null : onResolve,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD97706),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              icon: isResolving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.check_circle_outline, size: 18),
              label: Text(
                isResolving ? 'กำลังบันทึก...' : 'แก้ไขปัญหาแล้ว (คืนสถานะงาน)',
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontFamily: AppStyles.fontFamily,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RepairReportCard extends StatelessWidget {
  final AdminJobInfo job;
  final ValueChanged<String> onImageTap;

  const _RepairReportCard({required this.job, required this.onImageTap});

  @override
  Widget build(BuildContext context) {
    final photos = <MapEntry<String, String>>[
      if (job.reportBeforePhoto.isNotEmpty)
        MapEntry('ก่อนซ่อม', job.reportBeforePhoto),
      if (job.reportAfterPhoto.isNotEmpty)
        MapEntry('หลังซ่อม', job.reportAfterPhoto),
      if (job.reportSlipPhoto.isNotEmpty)
        MapEntry('สลิปโอนเงิน', job.reportSlipPhoto),
    ];

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: const BoxDecoration(
                  color: AppColors.greenBg,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.fact_check_outlined,
                    size: 18, color: AppColors.greenText),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'รายงานการซ่อมจากช่าง',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                    fontFamily: AppStyles.fontFamily,
                  ),
                ),
              ),
            ],
          ),
          if (job.reportSubmittedAt != null) ...[
            const SizedBox(height: 4),
            Text(
              'ส่งรายงานเมื่อ ${formatNotificationDateTime(job.reportSubmittedAt)}',
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textSubtitle,
                fontFamily: AppStyles.fontFamily,
              ),
            ),
          ],
          const SizedBox(height: 14),
          if (job.reportFormCode.isNotEmpty) ...[
            _InfoRow(label: 'รหัสฟอร์มซ่อม', value: job.reportFormCode),
            const SizedBox(height: 4),
          ],
          if (job.reportProblemDetail.isNotEmpty) ...[
            const Text(
              'รายละเอียดปัญหา/การซ่อม',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
                fontFamily: AppStyles.fontFamily,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              job.reportProblemDetail,
              style: const TextStyle(
                fontSize: 14,
                fontFamily: AppStyles.fontFamily,
                color: AppColors.textMain,
              ),
            ),
            const SizedBox(height: 12),
          ],
          if (photos.isNotEmpty) ...[
            const Text(
              'รูปภาพประกอบการปิดงาน (แตะเพื่อขยาย)',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
                fontFamily: AppStyles.fontFamily,
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 110,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: photos.length,
                separatorBuilder: (context, index) =>
                    const SizedBox(width: 10),
                itemBuilder: (context, index) {
                  final entry = photos[index];
                  return GestureDetector(
                    onTap: () => onImageTap(entry.value),
                    child: Column(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.network(
                            entry.value,
                            width: 80,
                            height: 100,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                Container(
                              width: 80,
                              height: 100,
                              color: Colors.grey.shade200,
                              child: const Icon(Icons.broken_image,
                                  color: Colors.grey),
                            ),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          entry.key,
                          style: const TextStyle(
                            fontSize: 11,
                            color: AppColors.textSubtitle,
                            fontFamily: AppStyles.fontFamily,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _AssignCard extends StatelessWidget {
  final List<TechnicianItem> technicians;
  final String? selectedTechnicianUsername;
  final String? assignedTechnicianName;
  final DateTime? appointmentDate;
  final TimeOfDay? appointmentTime;
  final String formattedTime;
  final bool isAssigning;
  final bool isCheckingQuota;
  final ValueChanged<TechnicianItem> onTechnicianTap;
  final Future<bool> Function() onPickDate;
  final Future<void> Function() onPickTime;
  final VoidCallback onAssign;

  const _AssignCard({
    required this.technicians,
    required this.selectedTechnicianUsername,
    required this.assignedTechnicianName,
    required this.appointmentDate,
    required this.appointmentTime,
    required this.formattedTime,
    required this.isAssigning,
    required this.isCheckingQuota,
    required this.onTechnicianTap,
    required this.onPickDate,
    required this.onPickTime,
    required this.onAssign,
  });

  @override
  Widget build(BuildContext context) {
    final hasTechnicians = technicians.isNotEmpty;
    final availableCount = technicians.where((t) => !t.isFull).length;
    final canAssign = selectedTechnicianUsername != null &&
        appointmentDate != null &&
        !isAssigning;

    return _SectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'มอบหมายช่าง',
            textAlign: TextAlign.center,
            style: AppStyles.title.copyWith(
              color: AppColors.textHeading,
              fontSize: 20,
              fontFamily: AppStyles.fontFamily,
            ),
          ),
          const SizedBox(height: 16),

          if (assignedTechnicianName != null) ...[
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.greenBg,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.check_circle,
                      color: AppColors.greenText, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'มอบหมายให้ $assignedTechnicianName แล้ว',
                      style: const TextStyle(
                        color: AppColors.greenText,
                        fontWeight: FontWeight.w600,
                        fontFamily: AppStyles.fontFamily,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],

          Row(
            children: [
              Expanded(
                flex: 6,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'วันนัดซ่อม',
                      style: AppStyles.inputLabel.copyWith(
                        fontSize: 13,
                        fontFamily: AppStyles.fontFamily,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Material(
                      color: AppColors.background,
                      borderRadius: BorderRadius.circular(10),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(10),
                        onTap: () => onPickDate(),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColors.border),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.calendar_month_outlined,
                                  size: 18, color: AppColors.primary),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  appointmentDate == null
                                      ? 'เลือกวัน'
                                      : AppointmentDate.toDisplay(
                                          appointmentDate!),
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontFamily: AppStyles.fontFamily,
                                    fontWeight: FontWeight.w600,
                                    color: appointmentDate == null
                                        ? AppColors.textHint
                                        : AppColors.textMain,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 4,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'เวลานัดหมาย',
                      style: AppStyles.inputLabel.copyWith(
                        fontSize: 13,
                        fontFamily: AppStyles.fontFamily,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Material(
                      color: AppColors.background,
                      borderRadius: BorderRadius.circular(10),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(10),
                        onTap: () => onPickTime(),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 12),
                          decoration: BoxDecoration(
                            border: Border.all(color: AppColors.border),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.access_time_outlined,
                                  size: 18, color: AppColors.primary),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  formattedTime,
                                  style: TextStyle(
                                    fontSize: 13,
                                    fontFamily: AppStyles.fontFamily,
                                    fontWeight: FontWeight.w600,
                                    color: appointmentTime == null
                                        ? AppColors.textHint
                                        : AppColors.textMain,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),

          Row(
            children: [
              Expanded(
                child: Text(
                  'เลือกช่างที่จะรับผิดชอบงานนี้',
                  style: AppStyles.inputLabel.copyWith(
                    fontSize: 13,
                    fontFamily: AppStyles.fontFamily,
                  ),
                ),
              ),
              if (hasTechnicians)
                Text(
                  'ว่าง $availableCount/${technicians.length} คน',
                  style: const TextStyle(
                    fontSize: 12,
                    fontFamily: AppStyles.fontFamily,
                    color: AppColors.textSubtitle,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 4),
          const Text(
            'ช่าง 1 คนรับได้ไม่เกิน '
            '${DatabaseHelper.maxJobsPerTechnicianPerDay} งานต่อวัน',
            style: TextStyle(
              fontSize: 12,
              fontFamily: AppStyles.fontFamily,
              color: AppColors.textHint,
            ),
          ),
          const SizedBox(height: 10),

          if (isCheckingQuota)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(
                child: CircularProgressIndicator(color: AppColors.primary),
              ),
            )
          else if (!hasTechnicians)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.surfaceAlt,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text(
                'ไม่พบรายชื่อช่างในระบบ',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 13,
                  fontFamily: AppStyles.fontFamily,
                  color: AppColors.textSubtitle,
                ),
              ),
            )
          else
            for (var i = 0; i < technicians.length; i++)
              Padding(
                padding: EdgeInsets.only(top: i == 0 ? 0 : 10),
                child: _TechnicianTile(
                  tech: technicians[i],
                  selected:
                      technicians[i].username == selectedTechnicianUsername,
                  onTap: () => onTechnicianTap(technicians[i]),
                ),
              ),

          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: canAssign ? onAssign : null,
              style: AppStyles.primaryButton.copyWith(
                padding: const WidgetStatePropertyAll(
                  EdgeInsets.symmetric(vertical: 14),
                ),
              ),
              child: isAssigning
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2.5,
                      ),
                    )
                  : Text(
                      assignedTechnicianName == null
                          ? 'มอบหมาย'
                          : 'มอบหมายใหม่',
                      style: AppStyles.buttonText.copyWith(
                        fontFamily: AppStyles.fontFamily,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TechnicianTile extends StatelessWidget {
  final TechnicianItem tech;
  final bool selected;
  final VoidCallback onTap;

  const _TechnicianTile({
    required this.tech,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final full = tech.isFull;
    const max = DatabaseHelper.maxJobsPerTechnicianPerDay;

    final borderColor = full
        ? AppColors.border
        : selected
            ? AppColors.primary
            : AppColors.border;

    final bgColor = full
        ? AppColors.surfaceAlt
        : selected
            ? AppColors.primary.withValues(alpha: 0.05)
            : AppColors.background;

    final nameColor = full ? AppColors.textHint : AppColors.textMain;

    return Material(
      color: bgColor,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: full ? null : onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            border: Border.all(
              color: borderColor,
              width: selected && !full ? 1.5 : 1,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Icon(
                full
                    ? Icons.block
                    : selected
                        ? Icons.radio_button_checked
                        : Icons.radio_button_unchecked,
                size: 20,
                color: full
                    ? AppColors.textHint
                    : selected
                        ? AppColors.primary
                        : AppColors.textSubtitle,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      full ? '${tech.name} (งานเต็ม)' : tech.name,
                      style: TextStyle(
                        fontSize: 14,
                        fontFamily: AppStyles.fontFamily,
                        fontWeight: FontWeight.w600,
                        color: nameColor,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'งานในวันที่เลือก ${tech.jobsOnSelectedDate}/$max',
                      style: TextStyle(
                        fontSize: 12,
                        fontFamily: AppStyles.fontFamily,
                        color:
                            full ? AppColors.textHint : AppColors.textSubtitle,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: full ? AppColors.redBg : AppColors.greenBg,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  full ? 'งานเต็ม' : 'ว่าง',
                  style: TextStyle(
                    fontSize: 11,
                    fontFamily: AppStyles.fontFamily,
                    fontWeight: FontWeight.w600,
                    color: full ? AppColors.redText : AppColors.greenText,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}